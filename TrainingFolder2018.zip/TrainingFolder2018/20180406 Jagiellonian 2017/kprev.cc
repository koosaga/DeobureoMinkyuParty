#include <bits/stdc++.h>
using namespace std;
const int MAXN = 200005;

bitset<MAXN> bs[26];
char str[MAXN], buf[MAXN];
int n;

int main(){
	int tc;
	scanf("%d",&tc);
	while(tc--){
		scanf("%s", str);
		n = strlen(str);
		for(int i=0; i<n; i++){
			bs[str[i] - 'a'].set(i + 1);
		}
		int q;
		scanf("%d",&q);
		bitset<MAXN> ans;
		for(int j=0; j<=n; j++) ans.set(j);
		for(int i=0; i<q; i++){
			bitset<MAXN> b0, b1;
			b0 = b1 = ans;
			b0.reset(n);
			b1.reset(n);
			scanf("%s", buf);
			for(int j=0; buf[j]; j++){
				b0 = b0 << 1;
				b1 = ((b1 << 1) & (bs[buf[j] - 'a'])) | b0;
				b0 &= bs[buf[j] - 'a'];
			}
			printf("%d\n", (b1&ans).count());
		}
		for(int i=0; i<n; i++){
			bs[str[i] - 'a'].reset(i + 1);
		}
	}
}
