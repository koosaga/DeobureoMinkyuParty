#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1000005;
const int MAXM = 1005;

int n, m;
int nxt[MAXN][26];
int dp[MAXM][MAXM];
char s[MAXN], t[MAXM];

int main(){
	int tc; scanf("%d",&tc);
	while(tc--){
		scanf("%s %s", s+1, t+1);
		n = strlen(s+1);
		m = strlen(t+1);
		memset(nxt[n+1], 0x3f, sizeof(nxt[n+1]));
		for(int i=n; i; i--){
			for(int j=0; j<26; j++){
				nxt[i][j] = nxt[i+1][j];
			}
			nxt[i][s[i] - 'a'] = i;
		}
		memset(dp[0], 0x3f, sizeof(dp[0]));
		dp[0][0] = 0;
		for(int i=1; i<=m; i++){
			dp[i][0] = 0;
			for(int j=1; j<=m; j++){
				dp[i][j] = dp[i-1][j];
				if(j > 0){
					int cur = dp[i-1][j-1];
					if(cur > 1e8) continue;
					cur = nxt[cur + 1][t[i] - 'a'];
					dp[i][j] = min(dp[i][j], cur);
				}
			}
		}
		int ans = 0;
		for(int i=m; i>=0; i--){
			if(dp[m][i] <= n){
				ans = i;
				break;
			}
		}
		printf("%d\n", ans);
	}
}
