#include<bits/stdc++.h>
using namespace std;

int a[10][100][4] = {
    {
        
    },
    {
        {1, 1, 1, 2}
    },
    {
        {1, 1, 1, 2},
        {1, 3, 1, 4},
        {1, 5, 1, 6},
    },
    {
        {1, 2, 1, 3},
        {1, 1, 2, 1},
        {1, 4, 2, 4},
        {3, 1, 3, 2},
        {2, 2, 2, 3},
        {3, 3, 3, 4}
    },
    {
        {1, 1, 1, 2},
        {3, 1, 4, 1},
        {1, 3, 1, 4},
        {2, 1, 2, 2},
        {4, 3, 4, 4},
        {4, 5, 3, 5},
        {4, 2, 3, 2},
        {1, 5, 2, 5},
        {3, 4, 2, 4},
        {3, 3, 2, 3}
    }
};

void solve()
{
    int n, i;
    scanf("%d", &n);
    if(n >= 5)
    {
        printf("impossible\n");
        return;
    }
    int l = n * (n + 1) / 2;
    for(int i=0; i<l; i++){
        for(int j=0; j<4; j++) printf("%d ", a[n][i][j]);
        puts("");
    }
}

int main()
{
    int t, i;
    scanf("%d", &t);
    for(i=0;i<t;i++)
        solve();
    return 0;
}
