#include<bits/stdc++.h>
using namespace std;
double tanasin(double x)
{
    return x/sqrt(max(0.0, 1-x*x));
}
double cosasin(double x)
{
    return sqrt(max(0.0, 1-x*x));
}
double solve(double h, double a, double b, double c, double va, double vb, double vc)
{
    double lo = 0;
    double hi = 1/max({va, vb, vc});
    for(int i=0; i<40; ++i)
    {
        double mi = (lo+hi)/2;
        double dH = tanasin(va*mi)*a+tanasin(vb*mi)*b+tanasin(vc*mi)*c;
        if(dH < h) lo = mi;
        else hi = mi;
    }
    double mi = (lo+hi)/2;
    //printf("%f %f %f\n", a/cos(ta), b/cos(tb), c/cos(tc));
    return a/cosasin(va*mi)/va + b/cosasin(vb*mi)/vb + c/cosasin(vc*mi)/vc;
}

int main()
{
    int T;
    scanf("%d", &T);
    while(T--)
    {
        int h, a, b, c, va, vb, vc;
        scanf("%d%d%d%d%d%d%d", &h, &a, &b, &c, &va, &vb, &vc);
        double ans = solve(h, a, b, c, va, vb, vc);
        assert(ans >= 0);
        assert(ans < 2*h);
        printf("%.12f\n", ans);
    }
    return 0;
}
