#include <bits/stdc++.h>
using namespace std;
typedef long long lint;
const int MAXN = 1000005;

int n, m;
lint a[MAXN];

int main(){
	int tc; scanf("%d",&tc);
	while(tc--){
		scanf("%d",&n);
		for(int i=1; i<=n; i++){
			int x;
			scanf("%d",&x);
			a[i] = a[i-1] + x;
		}
		lint ev = 1e18, od = 1e18, ans = -1e18;
		for(int i=1; i<=n; i++){
			if((i-1) % 2 == 0) ev = min(ev, a[i-1]);
			else od = min(od, a[i-1]);
			if(i % 2 == 0) ans = max(ans, a[i] - od);
			else ans = max(ans, a[i] - ev);
		}
		printf("%lld\n", ans);
	}
}
