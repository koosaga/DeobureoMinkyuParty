#include <bits/stdc++.h>
using namespace std;

const int MT = 30;

char arr[8][9];
int mem[2][MT + 1][64][64][64];

int dx[8] = {1, 1, 1, 0, 0, -1, -1, -1};
int dy[8] = {1, 0, -1, 1, -1, 1, 0, -1};

int f(int my, int t, int w, int b, int r)
{
    if(my < 0 || my > 1 || min({w, b, r}) < 0 || max({w, b, r}) >= 64)
    {
        printf("%d %d %d %d\n", my, w, b, r);
        exit(1);
    }
    
    int &m = mem[my][t][w][r][b];
    if(m == -1)
    {
        int wx, wy;
        int bx, by;
        int rx, ry;
        
        wx = w / 8;
        wy = w % 8;
        bx = b / 8;
        by = b % 8;
        rx = r / 8;
        ry = r % 8;
        
        if(my == 0)
        {
            assert(w != r && w != b);
            
            if(t == MT)
            {
                m = 50;
                return m;
            }
            
            for(int d = 0; d<8; d++)
            {
                int wx2 = wx + dx[d];
                int wy2 = wy + dy[d];
                if(wx2 < 0 || wx2 >= 8 || wy2 < 0 || wy2 >= 8)
                    continue;
                
                int w2 = wx2*8 + wy2;
                if(w2 == b)
                {
                    m = 0;
                    return m;
                }
            }
            
            if(r == b)
            {
                m = 50;
                return m;
            }
            
            if(rx == bx && (rx != wx || rx == wx && (wy > ry && wy > by || wy < ry && wy < by)))
            {
                m = 0;
                return m;
            }
            
            if(ry == by && (ry != wy || ry == wy && (wx > rx && wx > bx || wx < rx && wx < bx)))
            {
                m = 0;
                return m;
            }
            
            m = 50;
            int m2 = 50;
            
            for(int d = 0; d<8; d++)
            {
                if(rx == d || ry == wy && (rx < wx && d > wx || rx > wx && d < wx))
                    continue;
                
                int r2 = d*8 + ry;
                m2 = min(m2, f(1, t + 1, w, b, r2) + 1);
            }
            for(int d = 0; d<8; d++)
            {
                if(ry == d || rx == wx && (ry < wy && d > wy || ry > wy && d < wy))
                    continue;
                
                int r2 = rx*8 + d;
                m2 = min(m2, f(1, t + 1, w, b, r2) + 1);
            }
            for(int d = 0; d<8; d++)
            {
                int wx2 = wx + dx[d];
                int wy2 = wy + dy[d];
                if(wx2 < 0 || wx2 >= 8 || wy2 < 0 || wy2 >= 8)
                    continue;
                
                int w2 = wx2*8 + wy2;
                
                m2 = min(m2, f(1, t + 1, w2, b, r) + 1);
            }
            
            m = m2;
            return m;
        }
        else
        {
            assert(w != b && r != b);
            
            if(t == MT)
            {
                m = 50;
                return m;
            }
            
            if(w == r)
            {
                m = 50;
                return m;
            }
            
            for(int d = 0; d<8; d++)
            {
                int wx2 = wx + dx[d];
                int wy2 = wy + dy[d];
                if(wx2 < 0 || wx2 >= 8 || wy2 < 0 || wy2 >= 8)
                    continue;
                
                int w2 = wx2*8 + wy2;
                if(w2 == b)
                {
                    m = 50;
                    return m;
                }
            }
            
            m = 50;
            int m2 = 0;
            
            for(int d = 0; d<8; d++)
            {
                int bx2 = bx + dx[d];
                int by2 = by + dy[d];
                if(bx2 < 0 || bx2 >= 8 || by2 < 0 || by2 >= 8)
                    continue;
                
                int b2 = bx2*8 + by2;
                
                m2 = max(m2, f(0, t, w, b2, r));
            }
            if(m2 == 0)
            {
                if(rx == bx && (rx != wx || rx == wx && (wy > ry && wy > by || wy < ry && wy < by)))
                {
                    m2 = 0;
                }
                else if(ry == by && (ry != wy || ry == wy && (wx > rx && wx > bx || wx < rx && wx < bx)))
                {
                    m2 = 0;
                }
                else
                    m2 = 50;
            }
            
            m = m2;
            return m;
        }
    }
    return m;
}

void solve()
{
    int i, j, k, l;
    for(i=0;i<8;i++)
        scanf("%s", arr[i]);
    
    int wx, wy;
    int bx, by;
    int rx, ry;
    for(i=0;i<8;i++)
    {
        for(j=0;j<8;j++)
        {
            if(arr[i][j] == 'W')
            {
                wx = i;
                wy = j;
            }
            else if(arr[i][j] == 'B')
            {
                bx = i;
                by = j;
            }
            else if(arr[i][j] == 'R')
            {
                rx = i;
                ry = j;
            }
        }
    }
    
    int w, b, r;
    w = 8*wx + wy;
    b = 8*bx + by;
    r = 8*rx + ry;
    
    int ans = f(0, 0, w, b, r);
    printf("%d\n", ans);
}

int main2()
{
    memset(mem, -1, sizeof mem);
    int t, i;
    scanf("%d", &t);
    for(i=0;i<t;i++)
        solve();
    return 0;
}

int main()
{
    /*size_t sz = 1<<28;
    void* ns = malloc(sz);
    void* sp = ns + sz - sizeof(void*);
    asm __volatile__("movq %0, %%rax\n\t"
    "movq %%rsp, (%%rax)\n\t"
    "movq %0, %%rsp\n\t": : "r"(sp):);*/
    main2();
    //asm __volatile__("pop %rsp\n\t");
    return 0;
}

