#include<bits/stdc++.h>
using namespace std;
int main()
{
    int T; scanf("%d", &T);
    while(T--)
    {
        int N;
        scanf("%d", &N);
        vector<long long> V(N);
        for(auto& x: V) scanf("%lld", &x);
        sort(V.begin(), V.end());
        reverse(V.begin(), V.end());
        long long ans = 0;
        for(int i=0; i<N; ++i)
            ans += max(V[i]-i, 0ll);
        printf("%lld\n", ans);
    }
    return 0;
}
