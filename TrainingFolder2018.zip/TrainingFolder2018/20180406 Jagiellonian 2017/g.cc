#include<bits/stdc++.h>
using namespace std;
namespace FFT
{
    using base = complex<double>;
    void fft(vector<base>& a, bool inv)
    {
        int N =a.size(), j = 0;
        vector<base> roots(N/2);
        for(int i=1; i<N; ++i)
        {
            int bit = (N>>1);
            while(j>=bit)
            {
                j-=bit;
                bit >>= 1;
            }
            j += bit;
            if(i<j) swap(a[i], a[j]);
        }
        double ang = 2*acos(-1)/N*(inv?-1:1);
        for(int i=0; i<N/2; ++i)
            roots[i] = base(cos(ang*i), sin(ang*i));
        for(int i=2; i<=N; i<<=1)
        {
            int step = N/i;
            for(int j=0; j<N; j += i)
            {
                for(int k=0; k<i/2; ++k)
                {
                    base u = a[j+k], v = a[j+k+i/2]*roots[step*k];
                    a[j+k] = u+v;
                    a[j+k+i/2] = u-v;
                }
            }
        }
        if(inv) for(int i=0; i<N; ++i) a[i] /= N;
    }
    vector<int> multiply(const vector<int>& v, const vector<int>& w)
    {
        vector<base> fv(v.begin(), v.end()), fw(w.begin(), w.end());
        int n = 2; while(n < v.size() + w.size()) n <<= 1;
        fv.resize(n); fw.resize(n);
        fft(fv, 0); fft(fw, 0);
        for(int i=0; i<n; ++i) fv[i] *= fw[i];
        fft(fv, 1);
        vector<int> ret(n);
        for(int i=0; i<n; ++i) ret[i] = (int)round(fv[i].real());
        return ret;
    }
}
vector<int> mymult(const vector<int>& v, const vector<int>& w, int m)
{
    int N = v.size();
    vector<int> ans = FFT::multiply(v, w);
    vector<int> nv(N); 
    for(int i=0; i<N; ++i)
        nv[i] = (ans[i] + ans[i+N])%m;
    return nv;
    puts("==");
    for(auto x: v) printf("%7d ", x); puts("");
    for(auto x: w) printf("%7d ", x); puts("");
    for(auto x: nv) printf("%7d ", x); puts("");
    puts("==");
}

vector<int> ipow(vector<int> ans, vector<int> a, int b, int m)
{
    while(b)
    {
        if(b&1) ans = mymult(ans, a, m);
        a = mymult(a, a, m);
        b >>= 1;
    }
    return ans;
}

void tmain()
{
    int n, m, t;
    scanf("%d%d%d", &n, &m, &t);
    vector<int> init(n);
    for(int i=0; i<n; ++i)
    {
        int t; scanf("%d", &t);
        init[i] = t%m;
    }
    
    vector<int> x(n);
    x[0] = m-1;
    x[n-1] = (x[n-1] + 2)%m;
    vector<int> ans = ipow(init, x, t, m);
    for(int i=0; i<n; ++i)
    {
        if(ans[i] == 0) ans[i] = m;
        printf("%d ", ans[i]);
    }    
    puts("");
    return;
}

int main()
{
    int T; scanf("%d", &T);
    while(T--) tmain();    
}










