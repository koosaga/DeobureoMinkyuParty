#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1005;
const double dx[8] = {1, 0, -1, 0, 0.7, 0.7, -0.7, -0.7};
const double dy[8] = {0, 1, 0, -1, 0.7, -0.7, 0.7, -0.7};
int x[MAXN], y[MAXN];
int n;

double func(double px, double py){
	double ans = 0;
	for(int i=0; i<n; i++) ans += hypot(px - x[i], py - y[i]);
	return ans;
}

int main(){
	int tc;
	scanf("%d",&tc);
	while(tc--){
		scanf("%d",&n);
		double px = 0, py = 0;
		for(int i=0; i<n; i++){
			scanf("%d %d",&x[i],&y[i]);
			px += 1.0 * x[i] / n;
			py += 1.0 * y[i] / n;
		}
		//printf("%f %f\n", px, py);
		double ans = func(px, py);
		const double TEMP = 500;
		const int ITER = 10000;
		double d = *max_element(x, x+n) - *min_element(x, x+n);
		          +*max_element(y, y+n) - *min_element(y, y+n);
		d /= TEMP/10;
		for(int i=0; i<ITER; i++){
			d *= (1-1/TEMP);
			int dir = -1;
			if(i < (ITER*5/10))
			    ans = 1e100;
			double diff = 0;
			for(int j=0; j<8; j++){
				double tmp = func(px + d * dx[j], py + d * dy[j]);
				if(ans > tmp){
				    diff += (ans-tmp);
					ans = tmp;
					dir = j;
				}
			}
			if(dir != -1){
				px += dx[dir] * d;
				py += dy[dir] * d;
				if(diff < 1e12 && diff > ans/100000) --i;
			}
		}
		//printf("%.10f %.10f\n", func(px, py), func(0.0, 1.732051));
		printf("%.10f %.10f\n", px, py);
	}
}
