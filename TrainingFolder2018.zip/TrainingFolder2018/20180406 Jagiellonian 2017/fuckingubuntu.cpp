#include <bits/stdc++.h>
using namespace std;
using lint = long long;
using pi = pair<lint, lint>;
const int MAXN = 500005;
const int mod1 = 1e9 + 409;
const int mod2 = 1e9 + 433;
const int mul = 257;
using hash_t = long long;

struct print_hash{
	hash_t hv;
	int s, e, x;
};

struct answer{
	int sx, ex, sy, ey;
};

vector<pi> v;
int n;
string str[MAXN];
char buf[MAXN];
vector<int> pnt[MAXN];


answer solve(vector<pi> &v, int n, int m){
	for(auto &i : v) pnt[i.first].push_back(i.second);
	for(int i=0; i<n; i++){
		sort(pnt[i].begin(), pnt[i].end());
		pnt[i].resize(unique(pnt[i].begin(), pnt[i].end()) - pnt[i].begin());
	}
	for(int i=0; i<n; i++){
		for(int j=i+1; j<n; j++){
			int v1 = -1, v2 = -1;
			for(auto &k : pnt[i]){
				if(binary_search(pnt[j].begin(), pnt[j].end(), k)){
					if(v1 == -1) v1 = k;
					else if(v2 == -1) v2 = k;
					else break;
				}
			}
			if(v2 != -1) return (answer){i, j, v1, v2};
		}
	}
	return (answer){-1, -1, -1, -1};
}

pi add(lint h1, lint h2, int c){
	return pi((h1 * mul + c) % mod1, (h2 * mul + c) % mod2);
}

int main(){
	int tc;
	scanf("%d",&tc);
	for(int i=0; i<tc; i++){
		vector<print_hash> pfxHash, sfxHash;
		vector<lint> vx, vy;
		v.clear();
		scanf("%d",&n);
		for(int i=0; i<n; i++){
			scanf("%s", buf);
			str[i] = buf;
			lint h1 = 0, h2 = 0;
			for(int j=0; j+1<str[i].size(); j++){
				tie(h1, h2) = add(h1, h2, str[i][j]);
				lint k = h1 * mod2 + h2;
				v.push_back(pi(k, 0));
				pfxHash.push_back({k, i, 0, j});
			}
			h1 = h2 = 0;
			int tmp = v.size();
			for(int j=(int)str[i].size()-1; j>=1; j--){
				tie(h1, h2) = add(h1, h2, str[i][j]);
				lint k = h1 * mod2 + h2;
				v[--tmp].second = k;
				sfxHash.push_back({k, i, j, (int)str[i].size()-1});
			}
		}
		for(int i=0; i<v.size(); i++){
			vx.push_back(v[i].first);
			vy.push_back(v[i].second);
		}
		sort(vx.begin(), vx.end());
		sort(vy.begin(), vy.end());
		vx.resize(unique(vx.begin(), vx.end()) - vx.begin());
		vy.resize(unique(vy.begin(), vy.end()) - vy.begin());
		for(int i=0; i<v.size(); i++){
			v[i].first = lower_bound(vx.begin(), vx.end(), v[i].first) - vx.begin();
			v[i].second = lower_bound(vy.begin(), vy.end(), v[i].second) - vy.begin();
			printf("%lld %lld\n", v[i].first, v[i].second);
		}
		auto k = solve(v, vx.size(), vy.size());
		if(k.sx == -1) puts("NO");
		else{
			puts("YES");
			lint p = vx[k.sx], r = vx[k.ex];
			lint q = vy[k.sy], s = vy[k.ey];
			string PV, QV, RV, SV;
			for(auto &i : pfxHash){
				if(p == i.hv){
					PV = str[i.s].substr(i.e, i.x - i.e + 1);
				}
				if(r == i.hv){
					RV = str[i.s].substr(i.e, i.x - i.e + 1);
				}
			}
			for(auto &i : sfxHash){
				if(q == i.hv){
					QV = str[i.s].substr(i.e, i.x - i.e + 1);
				}
				if(s == i.hv){
					SV = str[i.s].substr(i.e, i.x - i.e + 1);
				}
			}
			cout << PV << QV << " " << RV << SV << endl;
			cout << RV << QV << " " << PV << SV << endl;
		}
	}
}
