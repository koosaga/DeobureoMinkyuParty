#include <bits/stdc++.h>
#pragma GCC target("popcnt")
//#pragma GCC optimize("O3")
using namespace std;
const int MAXN = 200192;

int FuckYou[1<<16];

inline int FuckingPopCount(uint64_t x){
	return __builtin_popcountll(x);
}

inline void myset(uint64_t a[], int x)
{
    a[x>>6] |= uint64_t(1) << (x&63);
}
inline void myreset(uint64_t a[], int x)
{
    a[x>>6] &= ~(uint64_t(1) << (x&63));
}
inline void myclear(uint64_t a[], int x)
{
    memset(a, 0, sizeof(uint64_t)*x);
}
inline void myresetend(uint64_t a[], int E, int sz)
{
    if(E==64) a[sz-1] = 0;
    else a[sz-1] &= ((uint64_t(1) << (64-E))-1);
}
inline void myset1(uint64_t a[], int x, int sz)
{
    memset(a, 0xff, sizeof(uint64_t)*x);
    myresetend(a, (x<<6)-sz ,x);
}
inline void SHL(uint64_t a[], int sz)
{
    for(int i=sz-1; i>=1; --i)
        a[i] = (a[i] << 1) | (a[i-1]>>63);
    a[0] = a[0] << 1;
}
inline void AND(uint64_t a[], uint64_t b[], int sz)
{
    for(int i=0; i<sz; ++i)
        a[i] &= b[i];
}
inline void OR(uint64_t a[], uint64_t b[], int sz)
{
    for(int i=0; i<sz; ++i)
        a[i] |= b[i];
}
inline int  COUNT(uint64_t a[], int sz)
{
    int ans = 0;
    for(int i=0; i<sz; ++i)
        ans += FuckingPopCount(a[i]);
    return ans;
}
uint64_t bs[26][MAXN/64];
uint64_t ans[MAXN/64], b0[MAXN/64], b1[MAXN/64];

char str[MAXN], buf[MAXN];
int n;

int main(){
	for(int i=1; i<65536; i++){
		FuckYou[i] = __builtin_popcount(i);
	}
	int tc;
	scanf("%d",&tc);
	while(tc--){
		scanf("%s", str);
		n = strlen(str);
		for(int i=0; i<n; i++)
		    myset(bs[str[i]-'a'], i+1);
		int q;
		scanf("%d",&q);
		int SIZE = n/64+1;
		
		myset1(ans, SIZE, n+1);
		//printf("%d\n", COUNT(ans, SIZE));
		for(int i=0; i<q; ++i)
		{
		    scanf("%s", buf);
		    int ll = strlen(buf);
		    if(ll == 1) printf("%d\n", n);
		    else
		    {
		        myset1(b0, SIZE, n);
		        myset1(b1, SIZE, n);
		       
		        for(int j=0; buf[j]; ++j)
		        {
		            SHL(b0, SIZE);
		            SHL(b1, SIZE);
		            AND(b1, bs[buf[j]-'a'], SIZE);
		            OR(b1, b0, SIZE);
		            AND(b0, bs[buf[j]-'a'], SIZE);
		        }
		        myresetend(b1, 64*SIZE-(n+1), SIZE);
		        printf("%d\n", (int)COUNT(b1, SIZE));
		    }
		}
		for(int i=0; i<n; ++i)
		    myreset(bs[str[i] - 'a'], i+1);
	}
}
