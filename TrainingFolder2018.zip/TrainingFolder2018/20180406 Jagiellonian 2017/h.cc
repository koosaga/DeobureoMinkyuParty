#include<bits/stdc++.h>
using namespace std;

vector<int> arr[200010];
int dis[200010];
int dis2[200010];
int par[200010];
bool chk[200010];

void f(int x, int p, int d, int *dis, bool u)
{
    if(u)
        par[x] = p;
    
    dis[x] = d;
    for(int &y : arr[x])
    {
        if(y == p)
            continue;
        f(y, x, d + 1, dis, u);
    }
}

void solve()
{
    int n, s, m, i;
    scanf("%d%d%d", &n, &s, &m);
    for(i=1;i<=n;i++)
        arr[i].clear();
    for(i=1;i<=n;i++)
        chk[i] = 0;
    
    for(i=0;i<n-1;i++)
    {
        int x, y;
        scanf("%d%d", &x, &y);
        arr[x].push_back(y);
        arr[y].push_back(x);
    }
    
    f(s, s, 0, dis, 1);
    f(m, m, 0, dis2, 0);
    
    int p = m;
    while(1)
    {
        chk[p] = 1;
        if(p == s)
            break;
        
        p = par[p];
    }
    
    priority_queue<pair<int, int>> pq;
    for(i=1;i<=n;i++)
        if(!chk[i])
            pq.push({dis2[i], i});
    pq.push({0, 0});
    
    int res = 2 * (n - 1);
    int ad = 0;
    while(!pq.empty())
    {
        int cnt, idx;
        tie(cnt, idx) = pq.top();
        pq.pop();
        
        if(chk[idx])
            continue;
        
        res = min(res, dis[m] + ad + cnt);
        
        if(idx)
        {
            int p = idx;
            while(1)
            {
                if(chk[p])
                    break;
                
                chk[p] = 1;
                ad += 2;
                
                p = par[p];
            }
        }
    }
    
    printf("%d\n", res);
}

int main()
{
    int t, i;
    scanf("%d", &t);
    for(i=0;i<t;i++)
        solve();
    return 0;
}
