#include<bits/stdc++.h>
using namespace std;
const long long MOD = 1e9+7;
namespace fft
{
    typedef long long base;
    void fft(vector<base> &a, bool inv, int mod)
    {
        int N = a.size(), j = 0;
        for(int i=1; i<N; ++i)
        {
            int bit = (N>>1);
            while(j >= bit)
            {
                j -= bit;
                bit >>= 1;
            }
            j += bit;
            if(i<j) swap(a[i], a[j]);
        }
        for(int i=2; i<=N; i<<=1)
        {
            int step = N/i;
            for(int j=0; j<N; j += i)
            for(int k=0; k<i/2; ++k)
            {
                if(inv)
                    a[j+k] -= a[j+k+i/2];
                else
                    a[j+k] += a[j+k+i/2];
                //base u = a[j+k], v = a[j+k+i/2];
                //a[j+k] = u+v*(inv?-1:1);
                //a[j+k+i/2] = v;
            }
        }
        for(int i=0; i<N; ++i)
        {
            a[i] = a[i]%mod;
            if(a[i] < 0) a[i] += mod;
        }
    }
}
bool isPrime(long long x)
{
    for(long long i=2; i*i<=x; ++i)
        if(x%i==0) return true;
    return false;
}
const int B = 1<<20;
int main()
{
    int N;
    vector<long long> x(B);
    vector<long long> fftx(B), fftx2(B);
    vector<long long> ffty(B), ffty2(B);
    vector<long long> fftz(B);
    unsigned long long F = 0;
    scanf("%d", &N);
    for(int i=0; i<N; ++i)
    {
        int t; scanf("%d", &t); x[t]++;
        F += t;
    }
    srand(F);
    int ff = 5e8;
    long long MOD2 = ff + (rand()%ff);
    while(isPrime(MOD2) == false) ++MOD2;
    fftx = x; fft::fft(fftx, false, MOD);
    fftx2 = x; fft::fft(fftx2, false, MOD2);
    for(int i=0; i<B; ++i) ffty[i] = (__builtin_popcount(i)%2)?MOD-1:1;
    for(int i=0; i<B; ++i) ffty2[i] = (__builtin_popcount(i)%2)?MOD2-1:1;
    for(int K=1; K<=20; ++K)
    {
        long long FFT = 0, FFT2 = 0;
        for(int i=0; i<B; ++i)
        {
            ffty[i] = (ffty[i] * fftx[i]) %MOD;
            ffty2[i] = (ffty2[i] * fftx2[i]) %MOD2;
            FFT += ffty[i];
            FFT2 += ffty2[i];
            if(FFT>=MOD) FFT -= MOD;
            if(FFT2 >= MOD2) FFT2 -= MOD2;
        }
        if(FFT != 0 || FFT2 != 0)
        {
            for(int i=1; i<K; ++i)
            {
                FFT = FFT * i; FFT %= MOD;
            }
            printf("%d %lld\n", K-1, FFT);
            return 0;
        }
    }
    puts("-1");
}







