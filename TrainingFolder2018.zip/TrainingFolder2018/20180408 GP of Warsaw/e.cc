#include <bits/stdc++.h>
const int MAXN = 500005;
using namespace std;
typedef pair<int, int> pi;
typedef long long lint;

int n, q;
set<pi> gph[MAXN];
map<pi, int> mp;
lint deg[MAXN], F[MAXN];
void getfunc(int v){
	lint maxOccur = gph[v].rbegin()->first;
	F[v] = max(deg[v] % 2, 2 * maxOccur - deg[v]);
}

int main(){
	scanf("%d",&n);
	for(int i=1; i<n; i++){
		int s, e, x;
		scanf("%d %d %d",&s,&e,&x);
		mp[pi(s, e)] = mp[pi(e, s)] = x;
		gph[s].insert(pi(x, e));
		gph[e].insert(pi(x, s));
		deg[s] += x;
		deg[e] += x;
	}
	lint ans = 0;
	for(int i=1; i<=n; i++){
		getfunc(i);
		ans += F[i];
	}
	printf("%lld\n", ans / 2);
	scanf("%d",&q);
	while(q--){
		int s, e, x;
		scanf("%d %d %d",&s,&e,&x);
		int prv = mp[pi(s, e)];
		mp[pi(s, e)] = mp[pi(e, s)] = x;
		gph[s].erase(pi(prv, e));
		gph[e].erase(pi(prv, s));
		deg[s] -= prv;
		deg[e] -= prv;
		gph[s].insert(pi(x, e));
		gph[e].insert(pi(x, s));
		deg[s] += x;
		deg[e] += x;
		ans -= F[s] + F[e];
		getfunc(s);
		getfunc(e);
		ans += F[s] + F[e];
		printf("%lld\n", ans/2);
	}
}
