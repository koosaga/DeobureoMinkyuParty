#include<bits/stdc++.h>
using namespace std;
long long __DP[2020][2020];
long long __B[2020][2020];
int K;
const int MOD = 1e9+7;
long long ipow(long long a, long long b)
{
    long long ret = 1;
    while(b)
    {
        if(b&1) ret = (ret*a)%MOD;
        a = (a*a)%MOD;
        b /= 2;
    }
    return ret;
}
long long I[2020][2020];
long long ipowgcd(int a, int b)
{
    if(I[a][b] != -1) return I[a][b];
    I[a][b] = ipow(K, __gcd(a, b));
    printf("I : %d %d %lld\n", a, b, I[a][b]);
    return I[a][b];
}
long long B(int, int);
long long DP(int, int);
long long DP(int N, int M)
{
    if(__DP[N][M] != -1) return __DP[N][M];
    long long &ans = __DP[N][M]; ans = 0;
    
    long long fact=  1;
    for(int i=1; i<=N; ++i) fact = (fact*i)%MOD;
    ans = 0;
    for(int L=1; L<=N; ++L)
    {
        long long npl = fact*ipow(L, MOD-2)%MOD;
        ans += npl*B(M, L);
        ans %= MOD;
    }
    printf("DP: %d %d %lld\n", N, M, ans);

    return ans;
}
long long B(int N, int M)
{
    if(__B[N][M] != -1) return __B[N][M];
    long long &ans = __B[N][M]; ans = 0;
    if(N == 0) return ans = 1;

    long long fact = 1;
    for(int i=1; i<=N; ++i)
    {
        ans += (fact * ipowgcd(i, M)) %MOD * B(N-i, M)%MOD;
        
        ans %= MOD;
        fact *= N-i;
        fact %= MOD;
    }
    printf("B : %d %d %lld\n", N, M, ans);

    return ans;
}
/*

2 2 2
I : 1 1 2
B : 1 1 2
I : 2 1 2
B : 2 1 6
I : 1 2 2
B : 1 2 2
I : 2 2 4
B : 2 2 8
DP: 2 2 20
*/
int main()
{
    memset(__DP, -1, sizeof(__DP));
    memset(__B, -1, sizeof(__B));
    memset(I, -1, sizeof(I));
    int N, M;
    scanf("%d%d%d", &N, &M, &K);
    long long ans = DP(N, M);
    for(int i=1; i<=N; ++i)
        ans = (ans*ipow(i, MOD-2))%MOD;
    for(int i=1; i<=M; ++i)
        ans = (ans*ipow(i, MOD-2))%MOD;
    printf("%lld\n", ans);
}
