#include <bits/stdc++.h>
using namespace std;
const int MAXN = 100005;
int n, a[MAXN];
int dp[MAXN];

int main(){
	scanf("%d",&n);
	for(int i=1; i<=n; i++) scanf("%d",&a[i]);
	for(int i=1; i<n; i++){
		if(a[i] > 0 && a[i+1] == 0){
			puts("-1");
			return 0;
		}
	}
	for(int i=1; i<=n; i++){
		if(a[i] != 0){
			for(int j=i+1; j<=n; j++){
				if(a[j] == 0){
					puts("-1");
					return 0;
				}
				if(a[j-1] > a[j]){
					int atl = 0;
					while((a[j] << atl) < a[j-1]) atl++;
					dp[j] = dp[j-1] + atl;
				}
				else{
					int atl = 0;
					while((a[j-1] << (atl + 1)) <= a[j]) atl++;
					dp[j] = max(0, dp[j-1] - atl);
				}
			}
			break;
		}
	}
	cout << accumulate(dp, dp + n + 1, 0ll) << endl;
}
