#include <bits/stdc++.h>
using namespace std;
using lint = long long;
using pi = pair<lint, lint>;
const int MAXN = 200005;

vector<int> gph[MAXN];
int deg[MAXN], n;
int a[MAXN], dot[MAXN];

double Do(vector<pi> v){
	double s = 0, e = 2e6;
	for(int i=0; i<50; i++){
		double m = (s+e)/2;
		double tmp = 1e19;
		bool ok = true;
		for(auto &j : v){
			tmp = min(tmp, j.first + m * j.second);
			if(tmp < j.first - m * j.second){
				ok = false;
				break;
			}
		}
		if(!ok) s = m;
		else e = m;
	}
	return s;
}

vector<int> dfn;
int sz[MAXN], msz[MAXN], vis[MAXN];

void dfs(int x, int p){
	sz[x] = 1;
	msz[x] = 0;
	for(auto &i : gph[x]){
		if(i != p && !vis[i]){
			dfs(i, x);
			sz[x] += sz[i];
			msz[x] = max(msz[x], sz[i]);
		}
	}
	dfn.push_back(x);
}

int get_center(int x){
	dfn.clear();
	dfs(x, -1);
	pi ans(1e9, 1e9);
	for(auto &i : dfn){
		int w = max(msz[i], (int)dfn.size() - sz[i]);
		ans = min(ans, pi(w, i));
	}
	return ans.second;
}

void dfs1(int x, int p, int d, vector<pi> &v){
	if(!dot[x]) v.push_back(pi(a[x], d));
	for(auto &i : gph[x]){
		if(i != p && !vis[i]){
			dfs1(i, x, d+1, v);
		}
	}
}

int main(){
	scanf("%d",&n);
	char str[50];
	for(int i=1; i<=n; i++){
		scanf("%s", str);
		if(*str == '*'){
			dot[i] = 1;
		}
		else{
			sscanf(str, "%d", &a[i]);
		}
	}
	if(count(dot + 1, dot + n + 1, 0) <= 1){
		puts("0");
		return 0;
	}
	for(int i=1; i<n; i++){
		int s, e;
		scanf("%d %d",&s,&e);
		gph[s].push_back(e);
		gph[e].push_back(s);
	}
	queue<int> que;
	que.push(1);
	double ans = 0;
	while(!que.empty()){
		int x = que.front();
		que.pop();
		x = get_center(x);
		vis[x] = 1;
		vector<pi> v;
		for(auto &i : gph[x]){
			if(vis[i]) continue;
			que.push(i);
			dfs1(i, x, 1, v);
		}
		sort(v.begin(), v.end());
		if(!dot[x]){
			for(int i=0; i<v.size(); i++){
				ans = max(ans, abs(a[x] - v[i].first) / (1.0 * v[i].second));
			}
		}
		ans = max(ans, Do(v));
	}
	printf("%.10f\n", ans);
}
