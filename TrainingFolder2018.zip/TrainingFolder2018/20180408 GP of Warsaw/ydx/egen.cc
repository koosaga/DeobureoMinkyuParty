#include <bits/stdc++.h>
using namespace std;
using lint = long long;
using pi = pair<lint, lint>;

int main(){
	printf("100000 100000\n");
	for(int i=0; i<2; i++){
		for(int j=0; j<100000; j++) printf("%d ", rand()%1048576);
		puts("");
	}
}
