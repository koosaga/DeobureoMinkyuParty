#include <bits/stdc++.h>
const int MAXN = 2005;
const int MAXM = 10005;
const int mod = 1e9 + 7;
using namespace std;
typedef pair<int, int> pi;
typedef long long lint;

int n, m;
vector<int> gph[MAXN];
vector<pi> edg;
lint dp[MAXN][MAXN], ie[MAXM];
int p[MAXN], deg[MAXN];

int main(){
	scanf("%d %d",&n,&m);
	for(int i=0; i<m; i++){
		int s, e;
		scanf("%d %d",&s,&e);
		edg.emplace_back(s, e);
		gph[s].push_back(e);
		deg[e]++;
	}
	int c = 0;
	queue<int> que;
	que.push(1);
	while(!que.empty()){
		int x = que.front();
		que.pop();
		p[x] = ++c;
		for(auto &i : gph[x]){
			deg[i]--;
			if(deg[i] == 0) que.push(i);
		}
	}
	for(int i=1; i<=n; i++){
		gph[i].clear();
	}
	for(auto &i : edg){
		i.first = p[i.first];
		i.second = p[i.second];
		gph[i.first].push_back(i.second);
	}
	sort(edg.begin(), edg.end());
	for(int i=1; i<=n; i++){
		dp[i][i] = 1;
		for(int j=1; j<=n; j++){
			for(auto &k : gph[j]){
				dp[i][k] += dp[i][j];
				dp[i][k] %= mod;
			}
		}
	}
	for(int i=1; i<=n; i++){
		for(int j=1; j<=n; j++){
			lint x = dp[i][j];
			x = (x * x % mod) * x % mod;
			dp[i][j] = x;
		}
	}
	lint ans = dp[1][n];
	for(int i=m-1; i>=0; i--){
		ie[i] = dp[edg[i].second][n];
		for(int j=i+1; j<m; j++){
			ie[i] += mod - ie[j] * dp[edg[i].second][edg[j].first] % mod;
			while(ie[i] >= mod) ie[i] -= mod;
		}
		ans += mod - ie[i] * dp[1][edg[i].first] % mod;
	}
	ans %= mod;
	cout << ans << endl;
}
