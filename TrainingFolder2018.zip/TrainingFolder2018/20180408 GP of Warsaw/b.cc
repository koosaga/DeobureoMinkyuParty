#include <bits/stdc++.h>
const int MAXN = 300005;
using namespace std;
typedef pair<int, int> pi;

int n, q, a[MAXN];
vector<int> v;

struct qry{
	int s, e, idx;
	bool operator<(const qry &q)const{
		return pi(s >> 9, e) < pi(q.s >> 9, q.e);
	}
}qr[MAXN];

int chk[MAXN], occ[MAXN], ans[MAXN];
int dap = 0;

void add(int x){
	if(chk[x]) return;
	chk[x] = 1;
	if(a[x] == 0) return;
	if(occ[a[x]] % 2 == 0) dap++;
	occ[a[x]]++;
}

void rem(int x){
	if(!chk[x]) return;
	chk[x] = 0;
	if(a[x] == 0) return;
	occ[a[x]]--;
	if(occ[a[x]] % 2 == 0) dap--;
}

int main(){
	scanf("%d",&n);
	scanf("%d",&q);
	for(int i=1; i<=n; i++){
		scanf("%d",&a[i]);
		v.push_back(a[i]);
	}
	v.push_back(0);
	sort(v.begin(), v.end());
	v.resize(unique(v.begin(), v.end()) - v.begin());
	for(int i=1; i<=n; i++){
		a[i] = lower_bound(v.begin(), v.end(), a[i]) - v.begin();
	}
	for(int i=0; i<q; i++){
		scanf("%d %d",&qr[i].s,&qr[i].e);
		qr[i].idx = i;
	}
	sort(qr, qr + q);
	int l = 1, r = 0;
	for(int i=0; i<q; i++){
		while(l > qr[i].s) add(--l);
		while(r < qr[i].e) add(++r);
		while(l < qr[i].s) rem(l++);
		while(r > qr[i].e) rem(r--);
		ans[qr[i].idx] = dap;
	}
	for(int i=0; i<q; i++) printf("%d\n", ans[i]);
}

