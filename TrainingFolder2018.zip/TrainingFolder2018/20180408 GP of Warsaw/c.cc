#include <bits/stdc++.h>
const int MAXN = 200005;
using namespace std;
typedef pair<int, int> pi;
typedef long long lint;

int n, m;
vector<int> gph[MAXN];
vector<int> dfn;
int sz[MAXN], ans[MAXN];

void dfs(int x){
	sz[x] = 1;
	for(auto &i : gph[x]){
		gph[i].erase(find(gph[i].begin(), gph[i].end(), x));
		dfs(i);
		sz[x] += sz[i];
	}
	sort(gph[x].begin(), gph[x].end(), [&](const int &a, const int &b){
		return sz[a] > sz[b];
	});
	dfn.push_back(x);
}

struct node{
	int mx; // subtree maxvalue
	int lazy; // subtree added lazy
	node *l, *r;
	node(){
		l = r = NULL;
		mx = lazy = 0;
	}
}*dp[MAXN];

void lazydown(node *p){
	if(!p->l) p->l = new node();
	p->l->lazy += p->lazy;
	p->l->mx += p->lazy;
	if(!p->r) p->r = new node();
	p->r->lazy += p->lazy;
	p->r->mx += p->lazy;
	p->lazy = 0;
}

void merge(node *dst, node *src, int s, int e){
	if(s == e){
		dst->lazy += src->lazy;
		dst->mx += src->lazy;
		return;
	}
	dst->lazy += src->lazy;
	lazydown(dst);
	int m = (s+e)/2;
	if(src->l){
		merge(dst->l, src->l, s, m);
	}
	if(src->r){
		merge(dst->r, src->r, m+1, e);
	}
	dst->mx = max(dst->l->mx, dst->r->mx);
}

void Do(node *p, int s, int e){
	if(s == e){
		if(p->mx >= s){
			p->lazy = p->mx = 0;
			ans[s]++;
		}
		return;
	}
	lazydown(p);
	int m = (s+e)/2;
	if(p->l->mx >= s){
		Do(p->l, s, m);
	}
	if(p->r->mx >= m+1){
		Do(p->r, m+1, e);
	}
	p->mx = max(p->l->mx, p->r->mx);
}

int main(){
	scanf("%d",&n);
	if(n == 1){
		cout << 1 << endl;
		return 0;
	}
	for(int i=1; i<n; i++){
		int s, e;
		scanf("%d %d",&s,&e);
		gph[s].push_back(e);
		gph[e].push_back(s);
	}
	dfs(1);
	for(auto &i : dfn){
		if(gph[i].empty()){
			dp[i] = new node();
		dp[i]->lazy++;
		dp[i]->mx++;
			continue;
		}
		dp[i] = dp[gph[i][0]];
		for(int j=1; j<gph[i].size(); j++){
			merge(dp[i], dp[gph[i][j]], 2, n);
		}
		dp[i]->lazy++;
		dp[i]->mx++;
		Do(dp[i], 2, n);
	}
	printf("%d\n", n);
	for(int i=2; i<=n; i++) printf("%d\n", ans[i]);
}
