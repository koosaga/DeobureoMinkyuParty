#include<bits/stdc++.h>
using namespace std;
const int MAXN = 501010;
const int STEP1 = 14;
const int STEP2 = 500; 
const int MOD = 1e9+7;
int N;
int a[MAXN], b[MAXN], ansarr[MAXN];
int perm[5040][7];
int perm2[5040][7];
int tp1, tp2;
int ans = MOD;
long long int othans = 0;
int chosen[14];
int notchosen[14];
vector<pair<int, int> > DoA()
{
    vector<pair<int, int> > F;
    for(int x=0; x<tp1; ++x)
    {
        long long ans = 0;
        for(int i=0; i<(N+1)/2; ++i)
        {
            ans += 1LL*a[i]*b[chosen[perm[x][i]]]%MOD;
        }
        F.emplace_back(int(ans%MOD), x);
    }
    return F;
}
vector<pair<int, int> > DoB()
{
    vector<pair<int, int> > F;
    for(int x=0; x<tp2; ++x)
    {
        long long ans = 0;
        for(int i=(N+1)/2; i<N; ++i)
        {
            ans += 1LL*a[i]*b[notchosen[perm2[x][i-(N+1)/2]]]%MOD;
        }
        F.emplace_back(int(ans%MOD), x);
    }
    return F;
}
int solve()
{
    //puts("S");
    vector<pair<int, int> > chosenA = DoA();
    vector<pair<int, int> > chosenB = DoB();
    int cv = chosenA.size();
    auto itmi = min_element(chosenA.begin(), chosenA.end());
    auto itma = max_element(chosenA.begin(), chosenA.end());
    int itmaf = itma->first;
    int itmas = itma->second;
    int itmif = itmi->first;
    int itmis = itmi->second;
    chosenA.emplace_back(itmaf-MOD, itmas);
    chosenA.emplace_back(itmif+MOD, itmis);
    sort(chosenA.begin(), chosenA.end());
/*
    printf("%d %d %d\n", chosen[0], chosen[1], notchosen[0]);
    for(auto x: chosenA) printf("%d ", x.first);
    puts("");
    for(auto x: chosenB) printf("%d ", x.first);
    puts("");
    puts("");*/
    for(auto x: chosenB)
    {
        int ind = lower_bound(chosenA.begin(), chosenA.end(), make_pair((2*MOD-(int)othans-x.first)%MOD, -1)) - chosenA.begin();
        if(ind == chosenA.size()) --ind;
        //printf("%d\n", ind);
        //printf("%d\n", x.first);
        int val = (((chosenA[ind].first%MOD + x.first)%MOD+MOD)%MOD+othans)%MOD;
        //printf("<%d>\n", val);
        if(ans > val)
        {
            ans = val;
            for(int i=0; i<(N+1)/2; ++i) ansarr[i] = chosen[perm[chosenA[ind].second][i]];
            for(int i=(N+1)/2; i<N; ++i) ansarr[i] = notchosen[perm2[x.second][i-(N+1)/2]];
        }
    }
}
void dfs(int maxv, int count)
{
    if(maxv == N && count == (N+1)/2)
    {
    
        solve();
        return;
    }
    if(maxv==N) return;
    if(maxv-count != N/2)
    {
        notchosen[maxv-count] = maxv;
        dfs(maxv+1, count);
    }
    if(count != (N+1)/2)
    {
        chosen[count] = maxv;
        dfs(maxv+1, count+1);
    }
    return;
}
void fav(){
    int bktk[STEP1];
    for(int i=0; i<N/2; ++i) bktk[i] = i;
    int tp = 0;
    do
    {
        for(int i=0; i<N/2; ++i) perm2[tp][i] = bktk[i];
        tp++;
    }while(next_permutation(bktk, bktk+N/2));
    tp2 = tp;
    for(int i=0; i<(N+1)/2; ++i) bktk[i] = i;
    tp = 0;
    do
    {
        for(int i=0; i<(N+1)/2; ++i) perm[tp][i] = bktk[i];
        tp++;
    }while(next_permutation(bktk, bktk+(N+1)/2));
    tp1 = tp;
    
    //tp1, tp2
    dfs(0, 0);
    
}
void rt(){
    for(int i=0; i<N; ++i) ansarr[i] = i;
    for(int i=STEP1; i<N; ++i)
    {
        othans = (othans + 1LL * a[i]*b[i])%MOD;
    }
    othans %= MOD;
    int n = N;
    N = 14;
    fav();
    N = n;
};
int main()
{
    scanf("%d", &N);
    for(int i=0; i<N; ++i) scanf("%d", a+i);
    for(int i=0; i<N; ++i) scanf("%d", b+i);
    if(N < STEP1)
        fav();
    else
        rt();
    printf("%d\n", ans);
    long long p = 0;
    for(int i=0; i<N; ++i)
    {
        printf("%d ", ansarr[i]+1);
        p = (p+1LL*a[i]*b[ansarr[i]])%MOD;
    }
    assert(p==ans);
    puts("");
    
    
}
