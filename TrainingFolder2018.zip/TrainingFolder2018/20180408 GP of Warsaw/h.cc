#include <bits/stdc++.h>
const int MAXN = 1000005;
const int mod = 1e9 + 7;
using namespace std;
typedef pair<int, int> pi;
typedef long long lint;

int n, m;
vector<int> gph[MAXN];
int dp[MAXN];

int f(int x){
	if(~dp[x])  return dp[x];
	int ret = 0;
	for(auto &i : gph[x]) ret = max(ret, f(i) + 1);
	return dp[x] = ret;
}
int main(){
	scanf("%d %d",&n,&m);
	for(int i=0; i<m; i++){
		int s, e;
		scanf("%d %d",&s,&e);
		gph[s].push_back(e);
	}
	lint ans = 0;
	memset(dp, -1, sizeof(dp));
	for(int i=1; i<=n; i++) ans += f(i) + 1;
	ans %= mod;
	cout << ans << endl;
}
