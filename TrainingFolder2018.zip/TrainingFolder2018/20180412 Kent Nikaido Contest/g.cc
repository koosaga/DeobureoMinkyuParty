#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100005;
const int mod = 1e9 + 7;
typedef pair<int, int> pi;
typedef long long lint;

int w, h, n, x[MAXN], y[MAXN], d[MAXN];
int mode[MAXN][4], dp[MAXN][4];

lint solve2(){
	memset(mode, 0, sizeof(mode));
	memset(dp, 0, sizeof(dp));
	for(int i=0; i<n; i++){
		int val = d[i] - 1;
		if((x[i] + y[i]) % 2) val ^= 2;
		mode[x[i]][val] = 1;
	}
	dp[0][0] = dp[0][2] = 1;
	for(int i=1; i<=h; i++){
		int msk = 0;
		for(int j=0; j<4; j++) if(mode[i][j]) msk |= (1<<j);
		for(int j=0; j<4; j++){
			if((msk & ~(1<<j))){
				dp[i][j] = 0;
			}
			else{
				dp[i][j] = dp[i-1][j] + dp[i-1][j^1];
				dp[i][j] %= mod;
			}
		}
	}
	return accumulate(dp[h], dp[h] + 4, 0ll);
}
lint solve(){
	memset(mode, 0, sizeof(mode));
	memset(dp, 0, sizeof(dp));
	for(int i=0; i<n; i++){
		int val = d[i] - 1;
		if((x[i] + y[i]) % 2) val ^= 2;
		mode[y[i]][val] = 1;
	}
	dp[0][0] = dp[0][1] = 1;
	for(int i=1; i<=w; i++){
		int msk = 0;
		for(int j=0; j<4; j++) if(mode[i][j]) msk |= (1<<j);
		for(int j=0; j<4; j++){
			if((msk & ~(1<<j))){
				dp[i][j] = 0;
			}
			else{
				dp[i][j] = dp[i-1][j] + dp[i-1][3-j];
				dp[i][j] %= mod;
			}
		}
	}
	return accumulate(dp[w], dp[w] + 4, 0ll);
}

struct rec{
	int sx, ex, sy, ey;
}rect[2];

rec merge(rec a, rec b){
	return (rec){max(a.sx, b.sx), min(a.ex, b.ex), max(a.sy, b.sy), min(a.ey, b.ey)};
}

lint gs(lint x, lint y, int b){
	return (x * y) / 2 + (x % 2 == 1 && y % 2 == 1 && b == 0);
}

lint getsum(rec a, int b){
	if(a.sx > a.ex || a.sy > a.ey) return 0;
	return gs(a.ex, a.ey, b) - gs(a.sx-1, a.ey, b) - gs(a.ex, a.sy-1, b) + gs(a.sx-1, a.sy-1, b);
}

int main(){
	scanf("%d %d",&w,&h);
	scanf("%d",&n);
	for(int i=0; i<n; i++){
		scanf("%d %d %d",&x[i],&y[i],&d[i]);
	}
	lint ans = 0;
	for(int i=0; i<2; i++){
		for(int i=0; i<2; i++){
			rect[i].sx = 1;
			rect[i].sy = 1;
			rect[i].ex = w-1;
			rect[i].ey = h-1;
		}
		for(int i=0; i<n; i++){
			int v = (x[i] + y[i]) % 2;
			int fuckx = x[i];
			int fucky = y[i];
			if(d[i] == 2){
				int x = fuckx;
				int y = fucky;
				rect[v] = merge(rect[v], (rec){x, w-1, y, h-1});
				rect[1-v] = merge(rect[1-v], (rec){1, x-1, 1, y-1});
			}
			if(d[i] == 4){	
				int x = fuckx;
				int y = fucky;
				rect[1-v] = merge(rect[1-v], (rec){x, w-1, y, h-1});
				rect[v] = merge(rect[v], (rec){1, x-1, 1, y-1});
			}
			if(d[i] == 3){
				int x = fuckx;
				int y = fucky;
				rect[1-v] = merge(rect[1-v], (rec){1, x-1, y, h-1});
				rect[v] = merge(rect[v], (rec){x, w-1, 1, y-1});
			}
			if(d[i] == 1){
				int x = fuckx;
				int y = fucky;
				rect[v] = merge(rect[v], (rec){1, x-1, y, h-1});
				rect[1-v] = merge(rect[1-v], (rec){x, w-1, 1, y-1});
			}
		}
		for(int i=0; i<2; i++){
			ans += getsum(rect[i], i);
		}
		for(int i=0; i<n; i++){
			d[i]--;
			d[i] ^= 2;
			d[i]++;
		}
	}
	int chk[10] = {};
	for(int i=0; i<n; i++){
		chk[d[i]] = 1;
	}
	if(!chk[2] && !chk[4]){
		int has = 0;
		for(int i=0; i<n; i++){
			int val = (x[i] + y[i]) % 2;
			if(d[i] == 3) val ^= 1;
			has |= 1<<val;
		}
		if(has == 0) ans += mod - 2;
		if(has == 1) ans += mod - 1;
		if(has == 2) ans += mod - 1;
	}
	if(!chk[1] && !chk[3]){
		int has = 0;
		for(int i=0; i<n; i++){
			int val = (x[i] + y[i]) % 2;
			if(d[i] == 4) val ^= 1;
			has |= 1<<val;
		}
		if(has == 0) ans += mod - 2;
		if(has == 1) ans += mod - 1;
		if(has == 2) ans += mod - 1;
	}
	swap(w, h);
	ans += solve();
	ans += solve2();
	ans %= mod;
	cout << ans << endl;
}
