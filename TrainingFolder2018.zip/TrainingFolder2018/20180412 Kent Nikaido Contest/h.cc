#include<bits/stdc++.h>
using namespace std;
int solve(int x)
{
    int v = 0;
    while(x)
    {
        v += x/2;
        x /= 2;
    }
    return v;
}
int main()
{
    int L, N;
    scanf("%d%d", &L, &N);
    int ans = (L-1)%2;
    for(int i=0; i<N; ++i)
    {
        int a, b; scanf("%d%d", &a, &b); --a; --b;
        int Nfact = solve(L-1);
        int multi = solve(b) + solve(a-b) + solve(L-1-a);
        if(Nfact == multi) ans ^=1;
    }
    if(ans) puts("Iori");
    else puts("Yayoi");
}
