#include<bits/stdc++.h>
using namespace std;
const int MAXN = 500005;
const int mod = 1e9 + 7;
typedef pair<int, int> pi;
typedef long long lint;

struct disj{
	int pa[MAXN];
	void init(int n){
		iota(pa, pa + n + 1, 0);
	}
	int find(int x){
		return pa[x] = (pa[x] == x ? x : find(pa[x]));
	}
	bool uni(int p, int q){
		p = find(p);
		q = find(q);
		if(p == q) return 0;
		pa[q] = p; return 1;
	}
}disj;

struct edg{
	int s, e, x;
	bool operator<(const edg &e)const{
		return x < e.x;
	}
}e[MAXN];

int n, m;
int sz[MAXN];
lint pwr[MAXN];
vector<pi> gph[MAXN];

lint dfs(int x, int p){
	lint ans = 0;
	for(auto &i : gph[x]){
		if(i.second == p) continue;
		ans += dfs(i.second, x);
		sz[x] += sz[i.second];
		if(sz[i.second] % 2) ans += pwr[i.first];
	}
	return ans % mod;
}

int main(){
	scanf("%d %d",&n,&m);
	disj.init(n);
	for(int i=0; i<m; i++){
		scanf("%d %d",&e[i].s,&e[i].e);
		sz[e[i].s] ^= 1;
		sz[e[i].e] ^= 1;
		e[i].x = i+1;
	}
	pwr[0] = 1;
	for(int i=0; i<=m; i++) pwr[i+1] = pwr[i] * 2 % mod;
	lint ans = pwr[m+1] + mod - 2;
	sort(e, e+m);
	for(int i=0; i<m; i++){
		if(disj.uni(e[i].s, e[i].e)){
			gph[e[i].s].push_back(pi(e[i].x, e[i].e));
			gph[e[i].e].push_back(pi(e[i].x, e[i].s));
		}
	}
	cout << (dfs(1, -1) + ans) % mod;
}
