#include<bits/stdc++.h>
using namespace std;
const int MOD = 1e9+7;
long long ipow(long long a, long long b)
{
    long long ret = 1;
    while(b)
    {
        if(b&1)ret = (ret*a)%MOD;
        a = (a*a)%MOD;
        b /= 2;
    }
    return ret;
}
int C(int A, int B)
{
    long long ans = 1;
    for(int i=1; i<=A; ++i)
        ans = (ans*i)%MOD;
    for(int i=1; i<=B; ++i)
        ans = (ans*ipow(i, MOD-2))%MOD;
    for(int i=1; i<=A-B; ++i)
        ans = (ans*ipow(i, MOD-2))%MOD;
    return ans;
}
int polya(int N, int K)
{
    long long ans = 0;
    for(int i=1; i<=N; ++i)
    {
        ans += ipow(K, __gcd(i, N));
        ans %= MOD;
    }
    ans *= ipow(N, MOD-2);
    ans %= MOD;
    return ans;
}
int special(int K)
{
    return ((ipow(K, 4) + 11 * ipow(K, 2))%MOD * ipow(12, MOD-2)%MOD);
}
int main()
{
    int N, K, L;
    scanf("%d%d%d", &N, &K, &L);
    if(N == L)
    {
        printf("%d\n", (int)polya(N, K));
        return 0;
    }
    if(L==2)
    {
        //K H N
        printf("%d\n", (int)C(K+N-1, N));
        return 0;
    }
    if(N == 4)
    {
        printf("%d\n", special(K)  );
        return 0;
    }
    assert(false);
    
}

// pLEASE HELP ME 




