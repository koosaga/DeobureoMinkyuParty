#include <bits/stdc++.h>
using namespace std;
const int MAXN = 100005;

struct seg{
	int tree[270000], lazy[270000];
	void lazydown(int p){
		tree[2*p] += lazy[p];
		tree[2*p+1] += lazy[p];
		lazy[2*p] += lazy[p];
		lazy[2*p+1] += lazy[p];
		lazy[p] = 0;
	}
	void add(int s, int e, int ps, int pe, int p, int v){
		if(e < ps || pe < s) return;
		if(s <= ps && pe <= e){
			tree[p] += v;
			lazy[p] += v;
			return;
		}
		int pm = (ps+pe)/2;
		lazydown(p);
		add(s, e, ps, pm, 2*p, v);
		add(s, e, pm+1, pe, 2*p+1, v);
		tree[p] = max(tree[2*p], tree[2*p+1]);
	}
	int query(){ return tree[1]; }
}seg;

int n, s[MAXN], t[MAXN];

int main(){
	scanf("%d",&n);
	for(int i=0; i<n; i++){
		scanf("%d %d",&s[i],&t[i]);
		seg.add(s[i], t[i] - 1, 1, MAXN, 1, 1);
	}
	int ans = 1e9;
	for(int i=0; i<n; i++){
		seg.add(s[i], t[i] - 1, 1, MAXN, 1, -1);
		ans = min(ans, seg.query());
		seg.add(s[i], t[i] - 1, 1, MAXN, 1, 1);
	}
	cout << ans << endl;
}
