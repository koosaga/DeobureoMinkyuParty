#include<bits/stdc++.h>
using namespace std;
const int MOD = 1e9+7;
int N, K, L;
long long dp[1010101];
int main()
{
    scanf("%d%d%d", &N, &K, &L);
        
}
