#include<bits/stdc++.h>
using namespace std;
#define FIRST "Iori"
#define SECOND "Yayoi"
int main()
{
	int sum = 0;
	int minv = 999;
	int N; scanf("%d", &N);
	for(int i=0; i<N; ++i)
	{
		int t;
		scanf("%d", &t);
		sum += t;
		minv = min(minv, t);
	}
	if(N%2==1)
	{
		if(sum%2==0) puts(SECOND);
		else puts(FIRST);
	}
	else
	{
		if(minv%2==1) puts(FIRST);
		else{
			if(sum%2==0) puts(SECOND);
			else puts(FIRST);
		}
	}
	return 0;
}
