#include<bits/stdc++.h>
using namespace std;
long long C[7];
long long T[7];
void C2T()
{
    
    //T[0]+T[1] = 2C[1]
    //T[1]+T[2] = 2C[2]
    //T[2]+T[3] = 2C[3]
    //T[3]+T[4] = 2C[4]
    //T[4]+T[5] = 2C[5]
    //T[5]+T[6] = 2C[6]
    //T[6]+T[0] = 2C[0]
    //2(T[0]+...+T[6]) = 2(C[0]+...+C[6])
    long long sum = 0;
    for(int i=0; i<7; ++i) sum += C[i];
    for(int i=0; i<7; ++i)
        T[i] = sum - 2*C[(i+2)%7] - 2*C[(i+4)%7] - 2*C[(i+6)%7];
}
bool casezero()
{
    C2T();
    //for(int i=0; i<7; ++i)
    //    printf("%lld ", T[i]);
    for(int i=0; i<7; ++i)
        if(T[i] < 0 || T[i]%2 != 0) return false;
    for(int L=-7; L<=0; ++L)
    {
        for(int R = -1; R<=7; ++R)
        {
            bool used[7];
            memset(used, false, sizeof used);
            for(int i=L; i<=R; ++i) used[(i+14)%7] = true;
            bool flag = false;
            for(int i=0; i<7; ++i)
            {
                if(!(
                    used[i] && T[i] > 0 ||
                    !used[i] && T[i] == 0))
                {
                    flag = true; break;
                }
            }
            if(!flag) return true;
        }
    }
    return false;
}
int main()
{
    for(int i=0; i<7; ++i) scanf("%lld", C+i);
    C[0]--;
    if(casezero())
    {
        puts("YES"); return 0;
    }
    for(int i=0; i<7; ++i)
    {
        if(T[0] %2 != T[i]%2)
        {
            puts("NO"); return 0;
        }
        if(T[i] <= 0)
        {
            puts("NO");
            return 0;
        }
    }
    puts("YES");
    return 0;
}





