#include<bits/stdc++.h>
using namespace std;
int main()
{
	int N; scanf("%d", &N);
	int cnt = 0;
	for(int i=0; i<N; ++i)
		for(int j=0; j<N; ++j)
		{
			char c; scanf(" %c", &c);
			if(c=='o' && (i+j)%4 == 0) cnt^=1;
		}
	printf("%d\n", cnt);
}
