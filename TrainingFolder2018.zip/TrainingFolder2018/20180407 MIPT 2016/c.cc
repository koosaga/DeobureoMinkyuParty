#include<bits/stdc++.h>
using namespace std;
const int MAXN = 505;
const int inf = 1e9;

int dp[2][MAXN][MAXN];
int n, k, a[MAXN], B, C;

int main(){
	cin >> n >> k >> B >> C;
	for(int i=1; i<=n; i++) cin >> a[i];
	memset(dp[0], 0x3f, sizeof(dp[0]));
	int cen = n/2;
	dp[0][0][cen] = 0;
	for(int i=1; i<=n; i++){
		memset(dp[i%2], 0x3f, sizeof(dp[i%2]));
		for(int j=1; j<=k; j++){
			for(int l=0; l<=2*cen; l++){
				dp[i%2][j][l] = min(l > 0 ? (dp[(i-1)%2][j-1][l-1] + a[i]) : inf, dp[(i-1)%2][j-1][l]);
			}
		}
		for(int l=0; l<=2*cen; l++){
			dp[i%2][0][l] = 
				min({dp[(i-1)%2][0][l] + a[i],
						(l + 1 <= 2 * cen) ? (dp[(i-1)%2][0][l+1] + C) : inf,
						dp[i%2][k][l] + B});
		}
	}
	cout << min(dp[n%2][0][cen], ((n+k-1)/k) * B) << endl;
}
