#include<bits/stdc++.h>
using namespace std;

const int MAXN = 131072;
int idx[2*MAXN];
int getv(int a, int b)
{
    a += MAXN; b += MAXN;
    int ans = 0;
    while( a <= b)
    {
        if(a%2==1) ans += idx[a++];
        if(b%2==0) ans += idx[b--];
        a /= 2; b/=2;
    }
    return ans;
}
void setv(int a, int v)
{
    idx[a += MAXN] = v;
    while((a = a/2))
        idx[a] = idx[2*a] + idx[2*a+1];
}

const double X = 1.8;
int main()
{
    int N; scanf("%d", &N);
    for(int i=1; i<=N; ++i) setv(i, 1);
    int lastvalue = 0;
    int cnt = 0;
    for(int i=0; i<N; ++i)
    {
        int t;
        scanf("%d", &t);
        if(t>lastvalue && getv(1, t) <= sqrt(getv(1, N)) * X)
        {
            //printf("%d\n", t);
            puts("1");
            for(int i=lastvalue+1; i<t; ++i)
                setv(i, 0);
            ++cnt;
            lastvalue = t;
        }
        else
        {
            puts("0");
        }
        setv(t, 0);
        fflush(stdout);
    }
    //printf("%d\n", cnt);
}
