print(100000)
import random
a = list(range(1, 100001))
random.shuffle(a)
for i in a: print(i)

