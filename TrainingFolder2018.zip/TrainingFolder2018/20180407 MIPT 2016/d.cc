#include<bits/stdc++.h>
using namespace std;

int arr[1000010];

int main()
{
    int n, h, i;
    scanf("%d%d", &n, &h);
    for(i=1;i<=n;i++)
        scanf("%d", &arr[i]);
    arr[0] = h;
    arr[n+1] = 0;
    
    double res = 0;
    double sav = 0;
    for(i=n; i>=0; i--)
    {
        double d = arr[i] - arr[i+1];
        if(sav >= d)
            continue;
        
        d -= sav;
        res += d;
        sav += d / 2;
    }
    
    printf("%.10lf\n", res);
    return 0;
}
