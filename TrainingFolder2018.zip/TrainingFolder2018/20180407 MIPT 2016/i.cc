#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1000005;
using real_t = double;
typedef pair<real_t, real_t> pi;
typedef long long lint;

struct inp
{
    real_t t, vx, vy;
    real_t v;
};

real_t ccw(pi a, pi b, pi c){
	real_t dx1 = b.first - a.first;
	real_t dy1 = b.second - a.second;
	real_t dx2 = c.first - a.first;
	real_t dy2 = c.second - a.second;
	return dx1 * dy2 - dy1 * dx2;
}

real_t dot(pi a, pi b, pi c){
	real_t dx1 = b.first - a.first;
	real_t dy1 = b.second - a.second;
	real_t dx2 = c.first - a.first;
	real_t dy2 = c.second - a.second;
	return dx1 * dx2 + dy1 * dy2;
}

real_t dist(pi a, pi b){
	return sqrt(dot(a, b, b));
}

real_t ans = 0;

real_t point_to_line(pi point, pi line_s, pi line_e, inp arr){
	if(dot(line_s, line_e, point) < 1e-9 || dot(line_e, line_s, point) < 1e-9){
	    
	    real_t dis_s = dist(point, line_s);
	    
	    real_t tmp = abs(arr.vx * line_s.second - line_s.first * arr.vy) / (dis_s * dis_s);
	    ans = max(ans, tmp);
	    
	    real_t dis_e = dist(point, line_e);
	    tmp = abs(arr.vx * line_e.second - line_e.first * arr.vy) / (dis_e * dis_e);
	    ans = max(ans, tmp);
	    
	    return -1;
	}
	return abs(ccw(point, line_s, line_e)) / dist(line_s, line_e);
}


real_t point_to_halfline(pi point, pi line_s, pi direction, inp arr){
	pi line_e = pi(line_s.first + direction.first, line_s.second + direction.second);
	if(dot(line_s, line_e, point) < 1e-9){
	
	    real_t dis = dist(point, line_s);
	    
	    real_t tmp = abs(arr.vx * line_s.second - line_s.first * arr.vy) / (dis * dis);
	    ans = max(ans, tmp);
	
		return -1;
	}
	return abs(ccw(point, line_s, line_e)) / dist(line_s, line_e);
}

inp arr[100010];
pi loc[100010];

int main(){
    real_t u, x0, y0;
    int n, i;
    scanf("%lf%lf%lf%d", &u, &x0, &y0, &n);
    for(i=0; i<=n; i++)
    {
        real_t t, vx, vy;
        scanf("%lf%lf%lf", &t, &vx, &vy);
        
        vx -= u;
        real_t v = sqrt(vx*vx + vy*vy);
        arr[i] = {t, vx, vy, v};
    }
    
    loc[0] = {x0 - arr[0].t * u, y0};
    for(i=1;i<=n;i++)
    {
        loc[i] = {loc[i-1].first + (arr[i].t - arr[i-1].t) * arr[i-1].vx,
                  loc[i-1].second + (arr[i].t - arr[i-1].t) * arr[i-1].vy};
    }
    pi dir = {arr[n].vx, arr[n].vy};
    
    for(i=1;i<=n;i++)
    {
        if(abs(arr[i-1].v) < 1e-9)
            continue;
            
        real_t t = point_to_line({0, 0}, loc[i-1], loc[i], arr[i-1]);
        ans = max(ans, arr[i-1].v / t);
    }
    
    if(abs(arr[n].v) >= 1e-9)
    {
        real_t t = point_to_halfline({0, 0}, loc[n], dir, arr[n]);
        ans = max(ans, arr[n].v / t);
    }
    
    printf("%.10lf\n", ans);
    return 0;
}

