import random

def Bernoulli(p):
    if random.random() < p: return 1
    return 0

def Theta(n, p):
    ans = - n * p 
    for i in range(n):
        ans += Bernoulli(p)
    ans += random.random() - 0.5
    ans /= (n*p*(1-p))**0.5
    return ans

def ave(a):
    return sum(a)/len(a)
    
def nvar(X, k):
    a = 0
    ans = 0
    for i in X:
        ans += abs(i-a)**k
    ans /= len(X)
    return ans
    
def vari(X):
    a = 0
    ans = 0
    for i in X:
        ans += abs(i-a)**2
    ans /= len(X)
    return ans

def a(n, p):
    return [Theta(n, p) for i in range(10000)]

if __name__ == '__main__':
    print(100)
    print(0.5)
    for i in range(1, 101):
        print(10000, end = " ")
        print(" ".join(map(str, a(i, 0.5))))


      
