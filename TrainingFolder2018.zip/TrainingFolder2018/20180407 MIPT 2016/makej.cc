#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1000005;
typedef pair<int, int> pi;
typedef long long lint;

int n = 1000000;
int perm[MAXN];

int main(){
	printf("1000000 2\n");
	for(int i=1; i<=n; i++) perm[i] = i;
	random_shuffle(perm + 1, perm + n + 1);
	for(int i=2; i<=n; i++) printf("%d %d\n", perm[i-1], perm[i]);
}
