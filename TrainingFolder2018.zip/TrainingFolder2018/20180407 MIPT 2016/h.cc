#include<bits/stdc++.h>
using namespace std;
const int MAXN = 150005;
using pi = pair<int, int>;
using lint = long long;
const int inf = 1e9;

struct event{
	int ins;
	pi intv;
};

lint F(int x){ return 1ll * x * (x+1)/ 2; }

lint cost(pi x){
	return F(x.second) - F(x.first - 1);
}

struct wrapper{
	set<pi> s;
	lint sum;
	lint query(){ return sum; }
	void add(pi i, vector<event> &e){
		e.push_back((event){1, i});
		sum += cost(i);
		s.insert(i);
	}
	void remove(pi i, vector<event> &e){
		s.erase(i);
		sum -= cost(i);
		e.push_back((event){-1, i});
	}
	void revert(vector<event> &e){
		reverse(e.begin(), e.end());
		for(auto &i : e){
			if(i.ins == -1){
				s.insert(i.intv);
				sum += cost(i.intv);
			}
			else{
				s.erase(i.intv);
				sum -= cost(i.intv);
			}
		}
		e.clear();
	}
}W;

struct query{ int s, e, x; };

void solve(int s, int e, vector<query> ev, lint sum){
	if(ev.empty()){
		for(int i=s; i<=e; i++){
			printf("%lld\n", W.query() - sum);
		}
		return;
	}
	vector<query> l, r;
	vector<int> add_to_wrp;
	int m = (s+e)/2;
	for(auto &i : ev){
		if(i.s <= s && e <= i.e){
			sum += i.x;
			add_to_wrp.push_back(i.x);
		}
		else{
			if(i.s <= m) l.push_back(i);
			if(i.e > m) r.push_back(i);
		}
	}
	vector<event> rev;
	for(auto &i : add_to_wrp){
		auto l = W.s.upper_bound(pi(i, 1e9));
		pi insinv = pi(i, i);
		if(l != W.s.begin()){
			l--;
			if(l->second >= i){
				auto intv = *l;
				W.remove(intv, rev);
				insinv = pi(intv.first, intv.second + 1);
			}
		}
		l = W.s.upper_bound(pi(insinv.second + 1, -1e9));
		if(l != W.s.end() && l->first == insinv.second + 1){
			insinv.second = l->second;
			W.remove(*l, rev);
		}
		l = W.s.lower_bound(pi(insinv.first, -1e9));
		if(l != W.s.begin()){
			l--;
			if(l->second == insinv.first - 1){
				insinv.first = l->first;
				W.remove(*l, rev);
			}
		}
		W.add(insinv, rev);
	}
	solve(s, m, l, sum);
	solve(m+1, e, r, sum);
	W.revert(rev);
}

int n;
char buf[5];
int val[MAXN], alive[MAXN];

int main(){
	scanf("%d",&n);
	vector<query> v;
	for(int i=1; i<=n; i++){
		int x;
		scanf("%s %d",&buf,&x);
		if(*buf == '-'){
			v.push_back({x, i - 1, val[x]});
			alive[x] = 0;
		}
		else{
			scanf("%*d");
			alive[i] = 1;
			val[i] = x;
		}
	}
	for(int i=1; i<=n; i++){
		if(alive[i]){
			v.push_back({i, n, val[i]});
		}
	}
	solve(1, n, v, 0);
}
