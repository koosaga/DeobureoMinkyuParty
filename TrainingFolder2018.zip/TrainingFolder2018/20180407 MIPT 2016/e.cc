#include<bits/stdc++.h>
using namespace std;
const int MOD = 1e9+7;
long long ipow(long long a, long long b)
{
    long long ret = 1;
    while(b)
    {
        if(b&1) ret *= a;
        a *= a;
        b /= 2;
        ret %= MOD; a %= MOD;
    }
    return ret;
}
int main()
{
    int N;
    scanf("%d", &N);
    vector<long long> P(0);
    P.push_back(1ll);
    for(int i=0; i<N; ++i)
    {
        //multiply (1+(M-i)N)
        P.push_back(0);
        for(int j=i; j>=0; --j)
            P[j+1] = (P[j+1] + P[j]*(MOD-i))%MOD;
    }
    P[0] = 0;
    long long pow2 = 2;
    long long ans = 0;
    for(int i=1; i<=N; ++i)
    {
        P[i] = (MOD-P[i])%MOD;
        ans += (P[i] * ipow(pow2-1, MOD-2));
        ans %= MOD;
        pow2 *= 2;
        pow2 %= MOD;
    }
    printf("%lld\n", ans);
}
