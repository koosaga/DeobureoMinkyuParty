#include<bits/stdc++.h>
using namespace std;
int main()
{
    int T;
    double p;
    scanf("%d%lf", &T, &p);
    scanf("%d", &N);
    double V = 0;
    for(int i=0; i<N; ++i)
    {
        double t; scanf("%d", &t);
        V += t*t;
    }
    V %= N;
    V -= 1;
    if(V<1e-9)
    {
        puts("1");
    }
    else
    {
        V = 1/V; // 12np(1-p)
        V /= 12*p*(1-p);
    }
    printf("%d\n",(int)(V+0.5));
}
