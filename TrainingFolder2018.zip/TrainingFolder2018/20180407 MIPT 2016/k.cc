#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200005;
typedef long long lint;
struct disj{
	int pa[MAXN];
	void init(int n){
		iota(pa, pa + n + 1, 0);
	}
	int find(int x){
		return pa[x] = (pa[x] == x ? x : find(pa[x]));
	}
	bool uni(int p, int q){
		p = find(p);
		q = find(q);
		if(p == q) return 0;
		pa[q] = p; return 1;
	}
}disj;

struct edg{ int s, e, x; };
vector<edg> v;

int n, m, a[MAXN];
int lo[MAXN];

int main(){
	scanf("%d %d",&n,&m);
	for(int i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	sort(a, a+n);
	for(int i=1; i<n; i++){
		v.push_back({0, i, a[0] + a[i]});
	}
	for(int i=0; i<n; i++){
		lo[i] = lower_bound(a, a+n, m - a[i]) - a;
	}
	int cur = n-1;
	for(int i=0; i<n; i++){
		cur = min(cur, n - 1);
		for(int j=cur; j>=lo[i]; j--){
			v.push_back({i, j, a[i] + a[j] - m});
		}
		cur = lo[i];
	}
	sort(v.begin(), v.end(), [&](const edg &a, const edg &b){
		return a.x < b.x;
	});
	disj.init(n);
	lint ret = 0;
	for(auto &i : v) if(disj.uni(i.s, i.e)) ret += i.x;
	cout << ret << endl;
}
