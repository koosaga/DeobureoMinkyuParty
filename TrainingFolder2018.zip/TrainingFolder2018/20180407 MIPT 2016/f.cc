#include<bits/stdc++.h>
using namespace std;
const int MAXN = 501010;
const int MOD = 1e9+7;
int ufd[MAXN];
void init(){iota(ufd, ufd+MAXN, 0);}
int Find(int a){ return ufd[a] == a? a: (ufd[a] = Find(ufd[a])); }
void Union(int a, int b){ ufd[Find(a)] = Find(b); }

struct edg{
    int s, e, x;
};
vector<edg > E;
vector<pair<int, int> > conn[MAXN], revconn[MAXN];
int N, M;
bool vis[MAXN];
pair<int, int> dfs(int a)
{
    
    if(vis[a]) return make_pair(0, 1);
    vis[a] = true;
    int ans1=1, ans2 = 1;
    for(auto x: conn[a])
    {
        int a, b;
        tie(a, b) = dfs(x.first);
        ans1 += a;
        ans2 = ((1LL*ans2*b)%MOD * x.second)%MOD;
    }
    for(auto x: revconn[a])
    {
        int a, b;
        tie(a, b) = dfs(x.first);
        ans1 += a;
        ans2 = (1LL*ans2*b)%MOD;
    }
    return make_pair(ans1, ans2);
}
int main()
{
    init();
    scanf("%d%d", &N, &M);
    for(int i=0; i<M; ++i)
    {
        int a, b, c;
        scanf("%d%d%d", &a, &b, &c);
        --a; --b;
        if(c%2==1) Union(a, b);
        E.push_back({a, b, c});
    }
    for(auto& x: E)
    {
        conn[Find(x.s)].emplace_back(Find(x.e), x.x);
        revconn[Find(x.e)].emplace_back(Find(x.s), x.x);
    }
    long long nyorong = 1;
    for(int i=0; i<N; ++i)
    {
        if(Find(i) == i && !vis[i])
        {
            pair<int, int> v = dfs(i);
            long long ans = v.second; 
            //printf("=%d %d\n", v.first, v.second);
            for(int i=0; i<v.first-1; ++i)
                ans = (ans*((MOD+1)/2))%MOD;
            ans = (ans * ((1LL*(v.first)*(v.first-1)/2+1)%MOD))%MOD;
            nyorong += ans+MOD-1;
        }
    }
    printf("%lld\n", nyorong % MOD);
    return 0;
}
