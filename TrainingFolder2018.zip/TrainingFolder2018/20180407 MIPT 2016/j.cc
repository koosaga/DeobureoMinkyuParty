#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define fore(i, b, e) for (int i = (int)(b); i <= (int)(e); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define pb push_back
#define fi first
#define se second
#define all(x) (x).begin(), (x).end()
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long long i64;
typedef unsigned long long u64;

#define end pidoras

const int maxn = 1000500;

int p[maxn], rk[maxn];
void init() { forn(i, maxn) p[i] = i; }
int get(int x) { return p[x] == x ? x : (p[x] = get(p[x])); }
bool unite(int x, int y) {
    x = get(x), y = get(y);
    if (x == y) return false;
    if (rk[x] > rk[y]) p[y] = x;
    else {
        if (rk[x] == rk[y]) ++rk[y];
        p[x] = y;
    }
    return true;
}

int val[maxn], nxt[maxn], end[maxn];
int sz = 1;

int d;

struct Array {
    vi a;
    int st;

    Array() : a(1), st(0) {}

    int& operator[](int i) {
        int pos = st - i;
        if (pos < 0) pos += d;
        assert(0 <= pos && pos < (int)a.size());
        return a[pos];
    }

    const int& operator[](int i) const {
        int pos = st - i;
        if (pos < 0) pos += d;
        assert(0 <= pos && pos < (int)a.size());
        return a[pos];
    }

    int size() const {
        return a.size();
    }

    void shift() {
        ++st;
        st %= d;
        if ((int)a.size() < d) a.push_back(0);
    }
};

int n;
vi e[maxn];
const int ROOT = 0;

void scan() {
    scanf("%d%d", &n, &d);
    forn(i, n-1) {
        int u, v;
        scanf("%d%d", &u, &v);
        e[u-1].pb(v-1);
        e[v-1].pb(u-1);
    }
}

void mergeWith(int& s1, int& s2) {
    if (s1 == 0 || s2 == 0) return;
//     cerr << "mw " << s1 << " " << s2 << endl;
    for (int i = s1; i; i = nxt[i]) {
//         cerr << "unite " << val[s1] << " " << val[i] << endl;
        unite(val[s1], val[i]);
    }
    for (int i = s2; i; i = nxt[i]) {
//         cerr << "unite " << val[s1] << " " << val[i] << endl;
        unite(val[s1], val[i]);
    }
    val[s2] = val[s1];
    nxt[s1] = nxt[s2] = 0;
    end[s1] = s1;
    end[s2] = s2;
}

void print(const Array& a) {
    forn(i, a.size()) {
        int t = a[i];
        while (t) cerr << val[t] << " ", t = nxt[t];
        cerr << endl;
    }
    cerr << "---------------" << endl;
}

void merge(Array& a, Array& b) {
    if (a.size() < b.size()) swap(a, b);
    mergeWith(a[0], b[0]);
    forn(bh, b.size()) if (bh) {
        int ah = d - bh;
        if (ah < a.size()) mergeWith(a[ah], b[bh]);
    }
    forn(bh, b.size()) {
        if (!b[bh]) continue;
        if (a[bh]) {
            int f = end[a[bh]];
//             assert(f && nxt[f] == 0);
            assert(f);
            assert(nxt[f] == 0);
            nxt[f] = b[bh];
            end[a[bh]] = end[b[bh]];
        } else {
            a[bh] = b[bh];
        }
    }
}

vi path;
Array dfs(int v, int anc) {
    int h = path.size();
    if (h >= d) unite(v, path[h-d]);
    path.pb(v);

    Array cur;
    int& st = cur[0];
    st = sz;
    val[st] = v;
    end[st] = sz;
    ++sz;
    for (int to: e[v]) if (to != anc) {
        merge(cur, const_cast<Array&>(static_cast<const Array&>((dfs(to, v)))));
    }
    path.pop_back();
    cur.shift();
    return cur;
}

void solve() {
    init();
    dfs(ROOT, -1);
    int res = 0;
    forn(i, n) res += p[i] == i;
    cout << res << endl;
}

int main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif

    scan();
    solve();

#ifdef LOCAL
    cerr << "Time elapsed: " << clock() / 1000 << " ms" << endl;
#endif
    return 0;
}
