#include<bits/stdc++.h>
using namespace std;
double Np[101][101];
double p;
double eval(int N, const vector<double>& wtf)
{
    double stdev = sqrt(N*p*(1-p));
    vector<int> cnt(N+1);
    vector<int> uni(300);
    for(auto x: wtf)
    {
        double reunion = stdev*x+N*p+0.5;
        int xunion;
        if(reunion > 0) xunion = reunion;
        else xunion = -(int)(-reunion)-1;
        double bv= (int)((reunion-xunion)*300);
        int v = bv;
        assert( v< 300);
        uni[v]++;
        int sex = xunion;
        if(sex< 0 || sex > N) 
        {
            //printf(">%f<", reunion);
            return 1e99;
        }
        cnt[sex]++;
    }
    vector<double> sigmas;
    //printf("===%d\n", N);
    for(int i=0; i<N; ++i)
    {
        int myN = wtf.size();
        double myP = Np[N][i];
        double myave = myN*myP;
        if(myave<30 && cnt[i] > 45) return 1e99;
        if(myave<30) continue;
        double mystdev = sqrt(myN*myP*(1-myP))+1;
        if(abs(cnt[i]-myave) < 1) continue;
        double sigma = abs((cnt[i]-myave)/mystdev);
        sigmas.push_back(sigma);
    }
    for(int i=0; i<300; ++i)
    {
        int myN=wtf.size();
        double myP = 1.0/300;
        double myave = myN*myP;
        double mystdev = sqrt(myN*myP*(1-myP))+1;
        double sigma = abs((uni[i]-myave)/mystdev);
        sigmas.push_back(sigma);
    }
    double ans = 0;
    for(auto x: sigmas) ans += exp(x);
    return ans/sigmas.size();
}
int main()
{
    int T;
    scanf("%d%lf", &T, &p);
    Np[0][0] = 1;
    for(int i=1; i<=100; ++i)
    {
        Np[i][0] = Np[i-1][0]*(1-p);
        for(int j=1; j<=i; ++j)
            Np[i][j] = Np[i-1][j]*(1-p) + Np[i-1][j-1]*p;
    }
    //T = 1;
    int x = 1;
    int E = 0;
    while(T--)
    {
        int N; scanf("%d", &N); vector<double> wtf(N);
        for(int i=0; i<N; ++i) scanf("%lf", &wtf[i]);
        vector<pair<double, int> > V;
        double wtf2 = 1e100;
        int ind = 1;
        for(int i=1; i<=100; ++i)
        {
            V.emplace_back(eval(i, wtf), i);
        }
        sort(V.begin(), V.end());
        printf("%d\n", (3*V[0].second+2*V[1].second+V[2].second+3)/6);
        E += abs(ind-(x++));
        //printf("%d %lf %lf %lf\n", ind, wtf2, eval(x++, wtf), *min_element(wtf.begin(), wtf.end()) );
    }
    //printf("%lf\n", (double)E/ x);
}
