print(200, 200)
for i in range(100):
    print("01"*100)
    print("10"*100)
