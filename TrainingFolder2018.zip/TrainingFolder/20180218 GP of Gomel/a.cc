#include<bits/stdc++.h>
using namespace std;
long long a, h;
int main()
{
    cin >> a>>h;
    cout << a*h << endl;
    return 0;
}
