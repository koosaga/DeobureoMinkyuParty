#include<bits/stdc++.h>
using namespace std;
int arr[123];
int N;
int main()
{
    int N; cin >> N;
    vector<int> V(N);
    for(auto&x:V) cin >> x;
    vector<int> dd;
    for(int i=0; i<N; ++i)
        dd[i] = i;
    do
    {
        bool flag = false;
        for(int i=0; i<N-1; ++i)
            if(dd[i] == dd[i+1])
    }while(next_permutation(dd.begin(), dd.end());
}
