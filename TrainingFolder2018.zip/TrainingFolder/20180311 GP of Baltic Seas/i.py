a = int(input())
b = int(input())

print(a-b)
"""
x = a - b

if x < 0: print(x)
elif x == 0: print(x)
else : print("+"+str(x))
"""

