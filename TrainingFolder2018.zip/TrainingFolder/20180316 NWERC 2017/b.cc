#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n; scanf("%d", &n);
    if(n<=3) puts("1");
    else printf("%d\n", n-2);
    return 0;
}
