N = 1000000
M = 1000000
Q = 100
print(N, M, Q)
for i in range(Q):
    import random
    print (random.randint(1, N*M-1))
    
