#include<bits/stdc++.h>
using namespace std;

mt19937 rng(0x9801);
int randint(int a, int b)
{
    return uniform_int_distribution<int>(a, b)(rng);
}

int main()
{
    return 0;
}
