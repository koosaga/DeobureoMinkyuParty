print(200)
for i in range(1, 21):
    for j in range(1, 11):
        print(i, j)
