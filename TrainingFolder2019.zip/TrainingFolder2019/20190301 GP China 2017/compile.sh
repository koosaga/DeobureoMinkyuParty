g++ $1.cpp -o $1 -O2 -std=c++11 -Wall
