#include <bits/stdc++.h>

using namespace std;

vector<int> arr[300010];
int deg[300010];

int main()
{
	int n, m, i;
	scanf("%d%d", &n, &m);
	for(i=0; i<m; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		arr[x].push_back(y);
		deg[y]++;
	}
	
	queue<int> q;
	for(i=0; i<n; i++)
		if(deg[i] == 0)
			q.push(i);
	
	for(i=0; i<n; i++)
	{
		if(q.empty())
		{
			puts("1");
			return 0;
		}

		int x = q.front();
		q.pop();
		
		for(int y : arr[x])
		{
			deg[y]--;
			if(deg[y] == 0)
				q.push(y);
		}
	}
	
	puts("0");
	return 0;
}
