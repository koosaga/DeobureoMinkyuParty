#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1000005;
using pi = pair<int, int>;
vector<pi> v;

int n, a[MAXN];

int main(){
	scanf("%d",&n);
	for(int i=0; i<n; i++) scanf("%d",&a[i]);
	sort(a, a + n);
	for(int i=0; i<n; ){
		int e = i;
		while(e < n && a[i] == a[e]) e++;
		v.emplace_back(a[i], e - i);
		i = e;
	}
	int ret = 0;
	if(v.size() >= 3){
		ret = max(ret, v[v.size() - 2].first - v[0].first);
		for(int i=v.size()-1; i>=0; i--){
			if(v[i].second > 1){
				ret = max(ret, v[i].first - v[1].first);
			}
		}
	}
	cout << ret << endl;
}
