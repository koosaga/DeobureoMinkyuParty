#include <bits/stdc++.h>
using namespace std;
const int MAXN = 250005;
const int mod = 998244353;
const int prr = 3;
using pi = pair<int, int>;
using lint = long long;
using base = long long;

lint ipow(int x, int p){
	lint ret = 1, piv = x;
	while(p){
		if(p & 1) ret = ret * piv % mod;
		piv = piv * piv % mod;
		p >>= 1;
	}
	return ret;
}

void fft(vector<base> &a, int inv){
	int n = a.size(), j = 0;
	vector<base> roots(n / 2);
	for(int i=1; i<n; i++){
		int bit = (n >> 1);
		while(j >= bit){
			j -= bit;
			bit >>= 1;
		}
		j += bit;
		if(i < j) swap(a[i], a[j]);
	}
	int ang = ipow(prr, (mod - 1) / n);
	if(inv) ang = ipow(ang, mod - 2);
	for(int i=0; i<n/2; i++){
		roots[i] = (i ? (1ll * roots[i-1] * ang % mod) : 1);
	}
	for(int i=2; i<=n; i<<=1){
		int step = n / i;
		for(int j=0; j<n; j+=i){
			for(int k=0; k<i/2; k++){
				base u = a[j+k], v = a[j+k+i/2] * roots[step * k] % mod;
				a[j+k] = (u + v) % mod;
				a[j+k+i/2] = (u + mod - v) % mod;
			}
		}
	}
	lint invn = ipow(n, mod - 2);
	for(int i=0; i<n; i++){
		if(inv) a[i] = a[i] * invn % mod;
	}
}

vector<lint> multiply(vector<lint> &v, vector<lint> &w){
	vector<base> fv(v.begin(), v.end());
	vector<base> fw(w.begin(), w.end());
	int n = 2;
	while(n < v.size() + w.size()) n <<= 1;
	fv.resize(n); fw.resize(n);
	fft(fv, 0);
	fft(fw, 0);
	for(int i=0; i<n; i++) fv[i] = fv[i] * fw[i] % mod;
	fft(fv, 1);
	vector<lint> ret(n);
	for(int i=0; i<n; i++) ret[i] = fv[i];
	return ret;
}

int n;
char str[MAXN];
lint fact[MAXN], invf[MAXN], pwr[MAXN];
int mark[MAXN];

lint solve(){
	lint ret = 0;
	vector<lint> p1(n), p2(n);
	for(int i=0; i<n; i++){
		if(mark[i]) p1[i] = invf[i];
		if(mark[i]) p2[n - i - 1] = invf[n - i - 1];
	}
	auto mul = multiply(p1, p2);
	for(int i=0; i<n-1; i++){
		ret += pwr[i] * (fact[n - i - 2] * mul[n - i - 2] % mod) % mod;
	}
	ret %= mod;
	return ret;
	/*
	for(int i=0; i<n; i++){
		for(int j=i+1; j<n; j++){
			if(mark[i] && mark[j]){
				ret += pwr[j - i - 1] * (fact[n - j + i - 1] * (invf[i] * invf[n - j - 1] % mod) % mod) % mod;
				ret %= mod;
			}
		}
	}*/
	return ret;
}

int main(){
	fact[0] = invf[0] = pwr[0] = 1;
	for(int i=1; i<MAXN; i++){
		fact[i] =fact[i-1] * i % mod;
		invf[i] = ipow(fact[i], mod - 2);
		pwr[i] = pwr[i-1] * 2 % mod;
	}
	scanf("%s", str);
	n = strlen(str);
	lint ret = 0;
	for(int i='a'; i<='z'; i++){
		for(int j=0; j<n; j++){
			if(str[j] == i) mark[j] = 1;
			else mark[j] = 0;
		}
		ret += solve();
	}
	cout << ret % mod << endl;
}
