#include <bits/stdc++.h>

using namespace std;

using lint = long long;
int N, M;

const int N_ = int(1.1e6);

lint inv[N_], fac[N_], invfac[N_];

lint ipow (lint a, lint b) {
	if(b < 0) {
		return ipow(inv[a], -b);
	}
	lint ret = 1;
	while(b > 0) {
		if(b & 1) (ret *= a) %= M;
		a = (a * a) % M;
		b >>= 1;
	}
	return ret;
}

int main() {
	scanf("%d%d", &N, &M);

	inv[1] = 1;
	fac[0] = fac[1] = 1;
	invfac[0] = invfac[1] = 1;
	for(int i = 2; i <= N; i++) {
		inv[i] = (M - M / i) * inv[M % i] % M;
		fac[i] = fac[i-1] * i % M;
		invfac[i] = invfac[i-1] * inv[i] % M;
	}

	lint ans = ipow(N, N-2);
	lint sub = 0;
	for(int k = (N+1)/2+1; k <= N-1; k++) {
		lint cur = (k * ipow(N-1, N-k-2) % M);
		(cur *= fac[N-1] * invfac[k] % M) %= M;
		(cur *= invfac[N-k-1]) %= M;
		(sub += cur) %= M;
	}
	(sub *= N) %= M;
	(ans += M-sub) %= M;

	printf("%lld\n", ans);
	return 0;
}
