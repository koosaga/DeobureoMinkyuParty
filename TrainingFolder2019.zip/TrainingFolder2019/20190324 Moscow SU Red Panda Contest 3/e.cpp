#include <bits/stdc++.h>
using namespace std;

const int p[] = {2, 3, 5, 7, 11, 13, 17, 19, 23};

long long gcd(long long x, long long y)
{
	return x ? gcd(y%x, x) : y;
}

long long lcm(long long x, long long y)
{
	long long g = gcd(x, y);
	return x / g * y;
}

int main()
{
	int n, i;
	scanf("%d", &n);
	
	int c = 1;
	int k = -1;
	for(i=0;; i++)
	{
		c *= p[i];
		if(2 * c > n)
		{
			k = i + 1;
			printf("%d\n", k);
			fflush(stdout);
			break;
		}
	}
	
	int t;
	scanf("%d", &t);
	assert(t == 1);
	
	long long m = 1;
	for(i=0; i<k+1; i++)
	{
		int y;
		scanf("%d", &y);
		assert(y != -1);
		
		if(y == 0)
			return 0;
		
		if(i == k)
			return 0;
		
		long long m2 = lcm(m, y);
		
		int r;
		if(m2 <= n)
		{
			r = y - 1;
			m = m2;
		}
		else
		{
			r = (m - 1) % y;
		}
		
		printf("%d\n", r);
		fflush(stdout);
	}
	
	return 0;
}



