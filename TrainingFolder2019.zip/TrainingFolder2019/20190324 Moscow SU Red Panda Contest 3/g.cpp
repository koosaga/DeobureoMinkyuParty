#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1000005;
const int B = 1005;
using pi = pair<int, int>;

int n, q, a[MAXN];

int nxt[MAXN];

struct query{ int t, x, y, z; };
bool upd[MAXN];

void Batch(vector<query> &Q){
	vector<int> v;
	int idx = 0;
	for(auto &i : Q){
		if(i.t == 1){
			v.push_back(i.x);
			v.push_back(i.x + 1);
			upd[i.x] = 1;
		}
		else{
			v.push_back(i.x);
			v.push_back(i.y);
		}
		idx++;
	}
	sort(v.begin(), v.end());
	v.resize(unique(v.begin(), v.end()) - v.begin());
	for(int i=0; i<v.size()-1; i++){
		if(upd[v[i]]){
			for(auto &j : Q){
				if(j.t == 1){
					if(j.x == v[i]){
						a[j.x] = j.y;
					}
					continue;
				}
				if(j.x <= v[i] && j.y >= v[i] + 1 && j.z == a[v[i]]){
					j.z++;
				}
			}
			upd[v[i]] = 0;
		}
		else{
			for(int j=v[i+1]-1; j>=v[i]; j--){
				nxt[a[j]] = nxt[a[j] + 1] + 1;
			}
			for(auto &j : Q){
				if(j.t == 2 && j.x <= v[i] && j.y >= v[i+1]){
					j.z += nxt[j.z];
				}
			}
			for(int j=v[i]; j<v[i+1]; j++) nxt[a[j]] = 0;
		}
	}
	for(auto &i : Q){
		if(i.t == 2) printf("%d\n", i.z - 1);
	}
	Q.clear();
}

namespace FIO{
	static char buf[1<<19];
	static int idx = 0;
	static int bytes = 0;
	static inline int _read(){
		if(!bytes || idx == bytes){
			bytes = (int)fread(buf, sizeof(buf[0]), sizeof(buf), stdin);
			idx = 0;
		}
		return buf[idx++];
	}
	static inline int _readInt(){
		int x = 0, s = 1;
		int c = _read();
		while(c <= 32) c = _read();
		if(c == '-') s = -1, c = _read();
		while(c > 32){
			x = 10 * x + (c - '0');
			c = _read();
		}
		if(s < 0) x = -x;
		return x;
	}
}

int main(){
	vector<query> qry;
	n = FIO::_readInt();
	q = FIO::_readInt();
	for(int i=0; i<n; i++){
		a[i] = FIO::_readInt();
	}
	while(q--){
		int t = FIO::_readInt();
		if(t == 1){
			int x, y;
			x = FIO::_readInt();
			y = FIO::_readInt();
			qry.push_back({1, x, y});
		}
		else{
			int l, r, k;
			l = FIO::_readInt();
			r = FIO::_readInt();
			k = FIO::_readInt();
			qry.push_back({2, l, r, k});
		}
		if(qry.size() > B){
			Batch(qry);
		}
	}
	Batch(qry);
}
