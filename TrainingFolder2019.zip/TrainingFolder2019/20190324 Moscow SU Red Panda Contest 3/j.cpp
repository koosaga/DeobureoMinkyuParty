#include <bits/stdc++.h>
using namespace std;
const int MAXN = 100005;
using pi = pair<int, int>;

int n, p[MAXN], par[17][MAXN], dep[MAXN];

int dist(int x, int y){
	int ret = dep[x] + dep[y];
	if(dep[x] < dep[y]) swap(x, y);
	int dx = dep[x] - dep[y];
	for(int i=0; i<17; i++){
		if((dx >> i) & 1) x = par[i][x];
	}
	for(int i=16; i>=0; i--){
		if(par[i][x] != par[i][y]){
			x = par[i][x];
			y = par[i][y];
		}
	}
	if(x != y) x = par[0][x];
	ret -= 2 * dep[x];
	return ret;
}

int main(){
	scanf("%d",&n);
	for(int i=1; i<n; i++){
		int x; scanf("%d",&x);
		par[0][i] = x;
		dep[i] = dep[x] + 1;
	}
	for(int i=1; i<17; i++){
		for(int j=1; j<=n; j++){
			par[i][j] = par[i-1][par[i-1][j]];
		}
	}
	long long ret = 0;
	for(int i=0; i<n; i++){
		scanf("%d",&p[i]);
		ret += dist(i, p[i]);
	}
	assert(ret % 2 == 0);
	ret /= 2;
	cout << ret << endl;
}

