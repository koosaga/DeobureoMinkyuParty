#include <bits/stdc++.h>

using namespace std;

int N, M;
vector<vector<int>> A, B;

struct edge {
	int u, v, c;
};
vector<edge> edges;

void go(vector<vector<int>> &a, function<int(int,int)> f) {
	for(int i = 0; i < a.size(); i++) {
		vector<pair<int,int>> vec;
		for(int j = 0; j < a[i].size(); j++) {
			vec.emplace_back(a[i][j], j);
		}
		sort(vec.begin(), vec.end());
		for(int j = 1; j < vec.size(); j++) {
			edges.push_back({f(i, vec[j].second), f(i, vec[j - 1].second), vec[j].first - vec[j - 1].first});
		}
	}
}

int par[int(1.1e5)];

int get(int x) {
	if(par[x] == x) return x;
	return par[x] = get(par[x]);
}

int main() {
	scanf("%d%d", &N, &M);
	A.resize(N, vector<int>(M));
	B.resize(M, vector<int>(N));
	for(int i = 0; i < N; i++) {
		for(int j = 0; j < M; j++) {
			scanf("%d", &A[i][j]);
			B[j][i] = A[i][j];
		}
	}

	go(A, [&](int i, int j) { return i * M + j; });
	go(B, [&](int i, int j) { return j * M + i; });

	sort(edges.begin(), edges.end(), [&](const edge &e1, const edge &e2) {
		return e1.c < e2.c;
	});

	for(int i = 0; i < N*M; i++) {
		par[i] = i;
	}

	long long ans = 0;
	for(edge &e : edges) {
		int a = get(e.u);
		int b = get(e.v);
		if(a != b) {
			ans += e.c;
			par[a] = b;
		}
	}

	printf("%lld\n", ans);
	return 0;
}
