n = 1000000
print(str(n) + " " + str(n))

import random

for i in range(0, n):
	print(str(i) + " ", end = "")

print("")

for q in range(0, n//2):
	print("1 3 3")
	print("2 0 1000000 " + str(random.randint(0,100)))
