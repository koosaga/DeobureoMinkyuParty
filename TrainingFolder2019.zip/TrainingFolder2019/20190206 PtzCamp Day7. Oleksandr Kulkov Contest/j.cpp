#include <bits/stdc++.h>

using namespace std;



int main()
{
	int n, m, i;
	scanf("%d%d", &n, &m);



	return 0;
}