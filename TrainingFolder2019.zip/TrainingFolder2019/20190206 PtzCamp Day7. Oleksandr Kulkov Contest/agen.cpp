#include <bits/stdc++.h>
using namespace std;

int main(){
	printf("12\n");
	for(int i=0; i<531441; i++) printf("%d ", rand() % 1000);
	puts("");

	for(int i=0; i<531441; i++) printf("%d ", rand() % 1000);
	puts("");
}
