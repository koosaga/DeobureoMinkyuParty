#include <bits/stdc++.h>
using namespace std;
const int MAXN = 2000005;
using lint = long long;
using pi = pair<int, int>;

int main(){
	
}
