print("10")

for i in range(0, 10):
	print("1000000")
	s = ''.join(str(j) + " " for j in range(0, 1000000))
	print(s)

