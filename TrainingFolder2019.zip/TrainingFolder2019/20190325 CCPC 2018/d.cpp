#include <bits/stdc++.h>
using namespace std;

const int mod = 1000000007;

int ipow(int x, int y)
{
	if(y == 0)
		return 1;
	if(y % 2)
		return 1LL * x * ipow(x, y - 1) % mod;
	int t = ipow(x, y/2);
	return 1LL * t * t % mod;
}

int inv(int x)
{
	return ipow(x, mod - 2);
}

int iinv[100010];

int v[100010];
vector<int> arr[100010];
int deg[100010];

int p[100010];
int m10[100010];
int m11[100010];
int m2[100010];

void f(int x, int par)
{
	int c = 0;
	for(int y : arr[x])
	{
		if(y == par)
			continue;
		
		c++;
		f(y, x);
	}
	
	if(c == 0)
	{
		p[x] = 0;
		m2[x] = v[x];
		m10[x] = v[x];
		m11[x] = 0;
		return;
	}
	
	int dsum = 0;
	int psum = 0;
	int m10sum = 0;
	int m11sum = 0;
	int m2dsum = 0;
	for(int y : arr[x])
	{
		if(y == par)
			continue;
		
		dsum = (dsum + iinv[deg[y]]) % mod;
		psum = (psum + p[y]) % mod;
		m10sum = (m10sum + m10[y]) % mod;
		m11sum = (m11sum + m11[y]) % mod;
		m2dsum = (m2dsum + 1LL * m2[y] * iinv[deg[y]]) % mod;
	}
	
	p[x] = ((1LL * iinv[c + 1] * iinv[c + 1] % mod * dsum) + (1LL * iinv[c + 1] * iinv[c] % mod * psum)) % mod;
	m2[x] = 1LL * iinv[c] * m10sum % mod;
	
	m10[x] = ((1LL * iinv[c] * m11sum) + (1LL * iinv[c] * iinv[c] % mod * m2dsum)) % mod;
	m11[x] = ((1LL * iinv[c + 1] * m11sum) + (1LL * iinv[c + 1] * iinv[c + 1] % mod * m2dsum)) % mod;
	for(int y : arr[x])
	{
		if(y == par)
			continue;
		
		m10[x] = (m10[x] + 1LL * iinv[c] * iinv[c] % mod * iinv[deg[y]] % mod * (m10sum - m10[y] + mod)) % mod;
		m10[x] = (m10[x] + 1LL * iinv[c] * iinv[c - 1] % mod * p[y] % mod * (m10sum - m10[y] + mod)) % mod;
		m11[x] = (m11[x] + 1LL * iinv[c + 1] * iinv[c + 1] % mod * iinv[deg[y]] % mod * (m10sum - m10[y] + mod)) % mod;
		m11[x] = (m11[x] + 1LL * iinv[c + 1] * iinv[c] % mod * p[y] % mod * (m10sum - m10[y] + mod)) % mod;
	}	
}

void solve()
{
	int n, s, i;
	scanf("%d", &n);
	for(i=1; i<=n; i++)
		arr[i].clear();
	
	for(i=1; i<=n; i++)
		scanf("%d", &v[i]);
	for(i=0; i<n-1; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		arr[x].push_back(y);
		arr[y].push_back(x);
	}
	scanf("%d", &s);
	
	for(i=1; i<=n; i++)
		deg[i] = (int)arr[i].size();
	
	f(s, -1);
	
	int r = (m10[s] % mod + mod) % mod;
	printf("%d\n", r);
}

int main()
{
	int t, i;
	for(i=1; i<100010; i++)
		iinv[i] = inv(i);
	
	scanf("%d",&t);
	for(i=1; i<=t; i++)
	{
		printf("Case %d: ", i);
		solve();
	}
	return 0;
}



