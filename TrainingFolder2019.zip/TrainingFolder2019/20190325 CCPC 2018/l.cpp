#include <bits/stdc++.h>

int 

int main() {
	return 0;
}
