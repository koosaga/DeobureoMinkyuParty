#include <bits/stdc++.h>
using namespace std;

const int mod = 1000000007;

int ipow(int x, int y)
{
	if(y == 0)
		return 1;
	if(y % 2)
		return 1LL * x * ipow(x, y - 1) % mod;
	int t = ipow(x, y/2);
	return 1LL * t * t % mod;
}

int inv(int x)
{
	return ipow(x, mod - 2);
}
	
int fac[100010];
int caf[100010];

void solve()
{
	int n, m;
	scanf("%d%d", &n, &m);
	
	if(n <= 2 || m <= 2)
	{
		puts("0");
		return;
	}
	
	int r = 1LL * fac[n + 1] * caf[4] % mod * caf[n - 3] % mod * fac[m + 1] % mod * caf[4] % mod * caf[m - 3] % mod;
	printf("%d\n", r);
}

int main()
{
	int t, i;
	
	fac[0] = 1;
	for(i=1; i<100010; i++)
		fac[i] = 1LL * i * fac[i - 1] % mod;
	
	for(i=0; i<100010; i++)
		caf[i] = inv(fac[i]);
	
	scanf("%d",&t);
	for(i=1; i<=t; i++)
	{
		printf("Case %d: ", i);
		solve();
	}
	return 0;
}










