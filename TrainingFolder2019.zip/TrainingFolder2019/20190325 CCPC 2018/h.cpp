#include <bits/stdc++.h>
using namespace std;

void fill_dis(int s, int dis[])
{
	memset(dis, -1, sizeof dis);
	queue<int> q;
	dis[s] = 0;
	q.push(s);
	while(1)
	{
		int x = q.front();
		q.pop();
		for(int y : arr[x])
		{
			if(dis[y] == -1)
			{
				dis[y] = dis[x] + 1;
				q.push(y);
			}
		}
	}
}

vector<int> arr[200010];
bool exi[200010];
bool cyc[200010];
int deg[200010];

int da[200010];
int db[200010];
int da2[200010];
int db2[200010];

bool cyc_dfs(int x, int p)
{
	if(exi[x])
		return 1;
	
	for(int y : arr[x])
	{
		if(y == p)
			continue;
		
		if(cyc_dfs(y, x))
			return 1;
	}
	
	return 0;
}

vector<int> cv;
void a2_dfs(int x, int p, int a2)
{
	cv.push_back(x);
	for(int y : arr[x])
	{
		if(y == p || !cyc[y] || y == a2)
			continue;
		
		a2_dfs(y, x, a2);
	}
}

bool exi_cyc[200010];

bool solve()
{
	int n, m, a, b, i;
	scanf("%d", &n);
	for(i=1; i<=n; i++)
		arr[i].clear();
	memset(exi, 0, sizeof exi);
	memset(deg, 0, sizeof deg);
	
	for(i=0; i<n; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		arr[x].push_back(y);
		arr[y].push_back(x);
		deg[x]++;
		deg[y]++;
	}
	scanf("%d", &m);
	for(i=0; i<m; i++)
	{
		int x;
		scanf("%d", &x);
		exi[x] = 1;
	}
	scanf("%d%d", &a, &b);
	
	fill_dis(a, da);
	fill_dis(b, db);
	
	for(i=1; i<=n; i++)
	{
		if(exi[i])
		{
			if(da[i] <= db[i])
				return 1;
		}
	}
	
	queue<int> q;
	for(i=1; i<=n; i++)
	{
		cyc[i] = 1;
		if(deg[i] == 1)
			q.push(i);
	}
	
	while(!q.empty())
	{
		int x = q.front();
		q.pop();
		
		cyc[x] = 0;
		
		for(int y : arr[x])
		{
			deg[y]--;
			if(deg[y] == 1)
				q.push(y);
		}
	}
	
	int a2 = -1;
	int b2 = -1;
	for(i=1; i<=n; i++)
	{
		if(!cyc[i])
			continue;
		
		if(a2 == -1 || da[i] < da[a2])
			a2 = i;
		if(b2 == -1 || db[i] < db[b2])
			b2 = i;
	}
	
	fill_dis(a2, da2);
	fill_dis(b2, db2);
	
	memset(exi_cyc, 0, sizeof exi_cyc);
	for(i=1; i<=n; i++)
	{
		if(!cyc[i] || i == b2)
			continue;
			
		if(exi[i])
		{
			exi_cyc[i] = 1;
			continue;
		}
		
		for(int y : arr[i])
		{
			if(cyc[y])
				continue;
			
			if(cyc_dfs(y, i))
			{
				exi_cyc[i] = 1;
				break;
			}
		}
	}
	
	if(e2.empty())
		return 0;
	
	cv.clear();
	a2_dfs(a2, -1, a2);
	
	int el = -1, er = -1;
	for(int x : cv)
	{
		if(!cyc_e
		if(el == -1)
		{
			el = er = x;
		}
	}
	
}

int main()
{
	int t, i;
	scanf("%d",&t);
	for(i=1; i<=t; i++)
	{
		printf("Case %d: ", i);
		bool r = solve();
		if(r)
			puts("Panda");
		else
			puts("Sheep");
	}
	return 0;
}
