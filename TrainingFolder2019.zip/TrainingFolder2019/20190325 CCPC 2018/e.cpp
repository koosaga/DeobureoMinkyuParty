#include <bits/stdc++.h>
using namespace std;
using lint = long long;
using pi = pair<lint, int>;
const int MAXN = 100005;

struct edg{
	int pos, cst, idx;
};

struct item{
	int weight, idx;
	bool operator<(const item &i)const{
		return weight < i.weight;
	}
};

int n, m, k;
vector<edg> gph[MAXN];
vector<int> cmp[MAXN], bcc[MAXN];
int cutThis[2 * MAXN], vis[MAXN];
int dfn[MAXN], low[MAXN], piv, c;

void dfs(int x, int p){
	dfn[x] = low[x] = ++piv;
	for(auto &i : gph[x]){
		if(p == i.idx) continue;
		if(!dfn[i.pos]){
			dfs(i.pos, i.idx);
			low[x] = min(low[x], low[i.pos]);
		}
		else low[x] = min(low[x], dfn[i.pos]);
	}
}

void color(int x, int p){
	if(p){
		bcc[p].push_back(x);
		cmp[x].push_back(p);
	}
	for(auto &i : gph[x]){
		if(cmp[i.pos].size()) continue;
		if(low[i.pos] >= dfn[x]){
			bcc[++c].push_back(x);
			cmp[x].push_back(c);
			color(i.pos, c);
		}
		else color(i.pos, p);
	}
}

vector<vector<item>> weights;
vector<vector<int>> retrace;

void solve(int c){
	vector<item> vect;
	if(bcc[c].size() == 2){
		int l = bcc[c][0];
		int r = bcc[c][1];
		for(auto &i : gph[r]){
			if(i.pos == l){
				vect.push_back({i.cst, i.idx});
			}
		}
		if(vect.size() != 2) vect.push_back({0, -1});
		weights.push_back(vect);
		return;
	}
	for(int i=1; i<bcc[c].size(); i++){
		int v = bcc[c][i];
		for(auto &j : gph[v]){
			if(j.pos == bcc[c][i-1]){
				vect.push_back({j.cst, j.idx});
			}
		}
	}
	for(auto &j : gph[bcc[c].back()]){
		if(j.pos == bcc[c][0]){
			vect.push_back({j.cst, j.idx});
		}
	}
	weights.push_back(vect);
}

const int MAXK = 1005;
lint dp[MAXK];
pi nxtDp[MAXK];

void dfs2(int x, int c){
	if(vis[x]) return;
	vis[x] = c;
	for(auto &i : gph[x]){
		if(!cutThis[i.idx]) dfs2(i.pos, c);
	}
}

void solve(){
	scanf("%d %d %d",&n,&m,&k);
	for(int i=0; i<m; i++){
		int s, e, x; scanf("%d %d %d",&s,&e,&x);
		gph[s].push_back({e, x, i});
		gph[e].push_back({s, x, i});
	}
	dfs(1, -1);
	color(1, 0);
	for(int i=1; i<=c; i++){
		solve(i);
	}
	assert(weights.size() == c);
	memset(dp, 0x3f, sizeof(dp));
	dp[0] = 0;
	retrace.resize(c);
	int idx = 0;
	for(auto &i : weights){
		sort(i.begin(), i.end());
		for(int j=1; j<=k-1; j++){
			nxtDp[j] = pi(dp[j - 1] + i[0].weight + i[1].weight, j - 1);
		}
		for(int j=2; j<i.size(); j++){
			for(int l = k - 1; l >= 2; l--){
				auto upd = nxtDp[l - 1];
				upd.first += i[j].weight;
				nxtDp[l] = min(nxtDp[l], upd);
			}
		}
		retrace[idx].resize(i.size() + 1);
		int ptr = 0;
		for(int j = 1; j <= k - 1; j++){
			if(dp[j] >= nxtDp[j].first){
				dp[j] = nxtDp[j].first;
				int updV = j - nxtDp[j].second;
				while(ptr < updV){
					retrace[idx][ptr++] = j - 1;
				}
			}
		}
		while(ptr <= i.size()) retrace[idx][ptr++] = k - 1;
		idx++;
	}
	printf("%lld\n", dp[k - 1]);
	int pos = k - 1;
	for(int i=weights.size()-1; i>=0; i--){
		int countV = 0;
		for(int j=0; j<retrace[i].size(); j++){
			if(retrace[i][j] >= pos){
				countV = j;
				if(j > 0) countV = j + 1;
				pos -= j;
				break;
			}
		}
		for(int j=0; j<countV; j++){
			if(~weights[i][j].idx){
	//			printf("I cut %d\n", weights[i][j].idx);
				cutThis[weights[i][j].idx] = 1;
			}
		}
	}
	assert(pos == 0);
	int cnt = 0;
	for(int i=1; i<=n; i++){
		if(!vis[i]){
			dfs2(i, ++cnt);
		}
		printf("%d ", vis[i]);
	}
	puts("");
}

int main(){
	int tc; scanf("%d",&tc);
	for(int i=1; i<=tc; i++){
		printf("Case %d: ", i);
		solve();
		weights.clear();
		retrace.clear();
		for(int j=0; j<MAXN; j++){
			bcc[j].clear();
			cmp[j].clear();
			gph[j].clear();
		}
		piv = c = 0;
		memset(dfn, 0, sizeof(dfn));
		memset(low, 0, sizeof(low));
		memset(cutThis, 0, sizeof(cutThis));
		memset(vis, 0, sizeof(vis));
	}
}
