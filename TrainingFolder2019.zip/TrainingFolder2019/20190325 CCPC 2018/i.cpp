#include <bits/stdc++.h>
using namespace std;
using lint = long long;
using pi = pair<int, int>;
const int MAXN = 100005;
const int MAXT = 270000;

struct seg{
	pi tree[MAXT];
	pi merge(pi a, pi b){
		if(a > b) swap(a, b);
		if(a.first == b.first) b.second += a.second;
		return b;
	}
	void init(int s, int e, int p, int *a){
		if(s == e){
			tree[p] = pi(a[s], 1);
			return;
		}
		int m = (s+e)/2;
		init(s, m, 2*p, a);
		init(m + 1, e, 2*p+1, a);
		tree[p] = merge(tree[2*p], tree[2*p+1]);
	}
	pi query(int s, int e, int ps, int pe, int p){
		if(e < ps || pe < s) return pi(0, 0);
		if(s <= ps && pe <= e) return tree[p];
		int pm = (ps+pe)/2;
		return merge(query(s, e, ps, pm, 2*p), query(s, e, pm+1, pe, 2*p+1));
	}
}seg;

int cx[MAXN], cy[MAXN];
int n, m;
pi a[MAXN];

void solve(){
	int dap = 0;
	lint dapcnt = 0;
	auto updAns = [&](int x, lint y){
		if(dap < x){
			dap = x;
			dapcnt = 0;
		}
		if(dap == x){
			dapcnt += y;
		}
	};
	memset(cx, 0, sizeof(cx));
	memset(cy, 0, sizeof(cy));
	scanf("%d",&n);
	vector<int> vx, vy;
	for(int i=0; i<n; i++){
		scanf("%d %d",&a[i].first,&a[i].second);
		vx.push_back(a[i].first);
		vy.push_back(a[i].second);
	}
	sort(vx.begin(), vx.end());
	sort(vy.begin(), vy.end());
	for(int i=0; i<n; i++){
		a[i].first = lower_bound(vx.begin(), vx.end(), a[i].first) - vx.begin();
		a[i].second = lower_bound(vy.begin(), vy.end(), a[i].second) - vy.begin();
		cx[a[i].first]++;
		cy[a[i].second]++;
	}
	sort(a, a + n);
	for(int i=0; i<vx.size(); i++) updAns(cx[i], 1);
	for(int i=0; i<vy.size(); i++) updAns(cy[i], 1);
	seg.init(0, vy.size() - 1, 1, cy);
	for(int i=0; i<n; ){
		int e = i;
		while(e < n && a[e].first == a[i].first) e++;
		vector<int> v = {-1};
		for(int j=i; j<e; j++){
			v.push_back(a[j].second);
			int w = cy[a[j].second];
			if(e - i > 1){
				int cnt = w + e - i - 1;
				updAns(cnt, 1);
			}
		}
		v.push_back(vy.size());
		for(int j=1; j<v.size(); j++){
			auto quer = seg.query(v[j-1] + 1, v[j] - 1, 0, vy.size() - 1, 1);
			if(quer.first > 0){
				quer.first += e - i;
				updAns(quer.first, quer.second);
			}
		}
		i = e;
	}
	if(dap == 1) dapcnt = n;
	if(dap == 2){
		dapcnt = 1ll * n * (n - 1) / 2;
	}
	printf("%d %lld\n", dap, dapcnt);
}

int main(){
	int tc;
	scanf("%d",&tc);
	for(int i=1; i<=tc; i++){
		printf("Case %d: ", i);
		solve();
	}
}
