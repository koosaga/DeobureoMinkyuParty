#include <bits/stdc++.h>

using namespace std;

using lint = long long;

// 514118239718

	lint mul(lint x, lint y, lint mod) {
		lint ret = 0;
		while(y > 0) {
			if(y & 3) {
				ret += x * (y & 3) % mod;
				ret %= mod;
			}
			y >>= 2;
			x <<= 2;
			x %= mod;
		}
		return ret;
	}

lint ispow (lint x, lint y, lint p) {
	lint ret = 1, piv = x % p;
	while(y){
		if(y&1) ret=(ret*piv)%p;
		piv=(piv*piv)%p;
		y>>=1;
	}
	return ret;
}


void gcd (lint a, lint b, lint &x, lint &y, lint &g) {
	if(b == 0) {
		x = 1;
		y = 0;
		g = a;
		return;
	}
	lint tx, ty;
	gcd(b, a%b, tx, ty, g);
	x = ty;
	y = tx - ty * (a / b);
}

lint main2(lint P, lint A, lint Q) {
	assert((Q - 1) % P != 0);
	if(A == 0) {
		return 0;
	}
	lint x, y, _;
	gcd(P, Q-1, x, y, _);
	if(x < 0) {
		x = (x % (Q-1) + (Q-1)) % (Q-1);
	}
	lint ans = ispow(A, x, Q);
	assert(ispow(ans, P, Q) == A);
	return ans;
}

void solve() {
	lint n, c; scanf("%lld%lld", &n, &c);

	lint p = sqrtl(n) + 1;
	while(n % p != 0) p--;
	lint q = n / p;
	if(p > q) swap(p, q);

	lint x1 = main2((1LL<<30)+3, c % p, p);
	lint x2 = main2((1LL<<30)+3, c % q, q);

	lint x = 0;
	{
		lint i, j, g;
		gcd(p, q, i, j, g);
		if(i < 0) i = (n+i) % n;
		if(j < 0) j = (n+j) % n;
		x += mul(mul(x1, j, n), q, n);
		x %= n;
		x += mul(mul(x2, i, n), p, n);
		x %= n;
	}

	printf("%lld\n", x);

}


int main() {

	int T;
	scanf("%d", &T);
	for(int t=1;t<=T;t++) {
		printf("Case %d: ", t);
		solve();
	}

	return 0;
}
