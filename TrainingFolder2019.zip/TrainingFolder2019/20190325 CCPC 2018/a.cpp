#include <bits/stdc++.h>
using namespace std;
using pi = pair<int, int>;
const int MAXN= 100005;

int n, m;
pi a[MAXN];

int solve(){
	scanf("%d %d",&n,&m);
	for(int i=0; i<n; i++) scanf("%d",&a[i].first);
	for(int i=0; i<n; i++) scanf("%d",&a[i].second);
	sort(a, a + n);
	for(int i=0; i<n; i++){
		m -= a[i].second;
		if(m < 0) return i;
	}
	return n;
}

int main(){
	int tc;
	scanf("%d",&tc);
	for(int i=1; i<=tc; i++){
		printf("Case %d: %d\n", i, solve());
	}
}
