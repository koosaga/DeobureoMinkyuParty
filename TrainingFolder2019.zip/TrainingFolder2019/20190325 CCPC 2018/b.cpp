#include <bits/stdc++.h>
using namespace std;
using lint = long long;
using pi = pair<int, int>;
const int MAXN = 200005;
const int MAXT = 530000;
struct seg{
	int lim, tree[MAXT];
	void init(int n){
		fill(tree, tree+ MAXT, -1.01e9);
		for(lim = 1; lim <= n; lim <<= 1);
	}
	void upd(int x, int v){
		x += lim;
		tree[x] = max(tree[x], v);
		while(x > 1){
			x >>= 1;
			tree[x] = min(tree[2*x], tree[2*x+1]);
		}
	}
	int query(int s, int e){
		s += lim;
		e += lim;
		int ret = 1e9;
		while(s < e){
			if(s%2 == 1) ret = min(ret, tree[s++]);
			if(e%2 == 0) ret = min(ret, tree[e--]);
			s >>= 1;
			e >>= 1;
		}
		if(s == e) ret = min(ret, tree[s]);
		return ret;
	}
}seg;

struct interval{
	int s, e, idx;
	bool operator<(const interval &i)const{
		return e < i.e;
	}
};

int n, m;
int a[MAXN][2], col[MAXN], mx[2], mn[2], bad;
vector<int> gph[MAXN];

void dfs(int x, int c){
	if(col[x]){
		if(col[x] != c) bad = 1;
		return;
	}
	col[x] = c;
	mx[0] = max(mx[0], a[x][(c-1)]);
	mx[1] = max(mx[1], a[x][1^(c-1)]);
	mn[0] = min(mn[0], a[x][(c-1)]);
	mn[1] = min(mn[1], a[x][1^(c-1)]);
	for(auto &i : gph[x]){
		dfs(i, 3 - c);
	}
}

void solve(){
	scanf("%d %d",&n,&m);
	for(int i=0; i<m; i++){
		int s, e; scanf("%d %d",&s,&e);
		gph[s].push_back(e);
		gph[e].push_back(s);
	}
	for(int i=1; i<=n; i++) scanf("%d %d",&a[i][0],&a[i][1]);
	memset(col, 0, sizeof(col));
	bad = 0;
	vector<interval> intv;
	for(int i=1; i<=n; i++){
		if(!col[i]){
			mx[0] = mx[1] = -1e9;
			mn[0] = mn[1] = 1e9;
			dfs(i, 1);
			int cidx = intv.size() / 2;
			intv.push_back({mn[0], mx[0], cidx});
			intv.push_back({mn[1], mx[1], cidx});
		}
	}
	if(bad){
		puts("IMPOSSIBLE");
		return;
	}
	sort(intv.begin(), intv.end());
	int m = intv.size() / 2;
	seg.init(m);
	int ret = 2e9;
	for(int i=0; i<intv.size(); ){
		int e = i;
		while(e < intv.size() && intv[i].e == intv[e].e) e++;
		for(int j=i; j<e; j++){
			seg.upd(intv[j].idx, intv[j].s);
		}
		ret = min(ret, intv[i].e - seg.query(0, m - 1));
		i = e;
	}
	printf("%d\n", ret);
}

int main(){
	int tc;
	scanf("%d",&tc);
	for(int i=1; i<=tc; i++){
		printf("Case %d: ", i);
		solve();
		for(int i=0; i<MAXN; i++) gph[i].clear();
	}
}
