./i < i.in > i.out && \
./itmp < i.in > itmp.out && \
diff i.out itmp.out
