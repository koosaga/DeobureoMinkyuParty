#include <bits/stdc++.h>
using namespace std;
const int MAXN = 505;
using lint = long long;

int n, mod;
lint dp[MAXN][MAXN][2];
lint D1[MAXN][MAXN];
lint D2[MAXN][MAXN];

int main(){
	cin >> n >> mod;
	dp[0][1][0] = 1;
	for(int i=1; i<n; i++){
		memset(D1, 0, sizeof(D1));
		memset(D2, 0, sizeof(D2));
		for(int pos = 0; pos <= i; pos++){
			for(int asc = pos; asc <= i; asc++){
				// dp[i][pos][asc][0]
				dp[pos][asc][0] %= mod;
				dp[pos][asc][1] %= mod;
				if(dp[pos][asc][0]){
					lint val = dp[pos][asc][0];
					D1[pos + 1][asc + 1] += val;
					D1[asc + 1][asc + 1] += mod - val;
					D1[pos][asc] += val;
					D1[pos + 1][asc] += mod - val;
					D2[0][asc - pos + 1] += val;
					D2[pos][asc + 1] += mod - val;
					/*
					for(int nxt = pos + 1; nxt <= asc; nxt++){
						dp[i + 1][nxt][asc + 1][0] += dp[i][pos][asc][0];
					}*/
					/*
					dp[i + 1][pos][asc][0] += dp[i][pos][asc][0];
					*/
					/*
					for(int nxt = 0; nxt < pos; nxt++){
						dp[i + 1][nxt][asc - (pos - nxt - 1)][1] += dp[i][pos][asc][0];
					}*/
				}
				// dp[i][pos][asc][1]
				if(dp[pos][asc][1]){
					lint val = dp[pos][asc][1];

					D1[pos + 1][asc + 1] += val;
					D1[asc + 1][asc + 1] += mod - val;
					D2[pos][asc] += val;
					D2[pos + 1][asc + 1] += mod - val;
					D2[0][asc - pos] += val;
					D2[pos][asc] += mod - val;
					/*
					for(int nxt = pos + 1; nxt <= asc; nxt++){
						dp[i + 1][nxt][asc + 1][0] += dp[i][pos][asc][1];
					}
					dp[i + 1][pos][asc][1] += dp[i][pos][asc][1];
					for(int nxt = 0; nxt < pos; nxt++){
						dp[i + 1][nxt][asc - (pos - nxt)][1] += dp[i][pos][asc][1];
						}
					 */
				}
			}
		}
		// make d1, d2
		// make dp
		int pos = i;
		for(int i=1; i<=pos + 1; i++){
			for(int j=i; j<=pos + 1; j++){
				D2[i][j+1] += D2[i-1][j];
				D1[i][j] += D1[i-1][j];
			}
		}
		for(int i=0; i<=pos + 1; i++){
			for(int j=i; j<=pos + 1; j++){
				dp[i][j][0] = D1[i][j] % mod;
				dp[i][j][1] = D2[i][j] % mod;
			}
		}
	}
	lint dap = 0;
	for(int pos = 0; pos <= n; pos++){
		for(int asc = pos; asc <= n; asc++){
			dap += dp[pos][asc][0] + dp[pos][asc][1];
			dap %= mod;
		}
	}
	cout << dap << endl;
}
