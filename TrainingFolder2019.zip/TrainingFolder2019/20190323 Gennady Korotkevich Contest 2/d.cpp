#include <bits/stdc++.h>

using namespace std;

const int N_ = 405;
const int BOUND = 200000;

int X;
char S[N_];

int C[N_];

using lint = long long;

lint tb[BOUND+1];
short rev[N_][BOUND+1];

int ord[N_];

lint ans, cost[BOUND+1];

int main() {
	scanf("%d%s", &X,S+1);
	int N = strlen(S+1);
	for(int i = 1; i <= N; i++) {
		C[i] = C[i-1] + (S[i] == 'Y');
	}
	
	fill(tb+1, tb+BOUND+1, lint(1e17));
	for(int i = 1; i <= N; i++) {
		ord[i] = i;
		for(int w = i; w <= BOUND; w++) {
			if(tb[w - i] + C[i] < tb[w]) {
				rev[i][w] = i;
				tb[w] = tb[w - i] + C[i];
			}
		}
	}
	
	sort(ord+1, ord+N+1, [&](const int &i, const int &j) {
		//return C[i] / i < C[j] / j;
		return C[i] * j < C[j] * i;
	});
		
	int best = ord[1];
	
	if(X > BOUND) {
		int much = (X - BOUND) / best;
		cost[best] += much;
		ans += much * C[best];
		X -= much * best;
	}
	while(X > BOUND) {
		int much = 1;
		cost[best] += much;
		ans += much * C[best];
		X -= much * best;
	}
	
	assert(0 <= X && X <= BOUND);
	ans += tb[X];
	for(int i = N, w = X; i > 0; ) {
		int c = rev[i][w];
		if(c > 0) {
			cost[i] += 1;
			w -= c;
		}else {
			i -= 1;
		}
	}
	
	
	printf("%lld\n", ans);
	for(int i = N-1; i > 0; i--) {
		cost[i] += cost[i+1];
	}
	for(int i = 1; i <= N; i++) {
		printf("%lld ", cost[i]);
	}
	puts("");
	
	return 0;
}
