#include <bits/stdc++.h>
using namespace std;
const int MAXN = 200005;
using lint = long long;

int n, m, a[MAXN];

lint solve(){
	lint ret = 0, cur = 0;
	for(int i=1; i<=n; i++){
		if(i % 2 == 1) cur += a[i];
		else cur += m - a[i];
		cur %= m;
		ret += min(cur, m - cur);
	}
	assert(cur == 0);
	return ret;
}

int main(){
	scanf("%d %d",&n,&m);
	for(int i=1; i<=n; i++){
		scanf("%d",&a[i]);
	}
	for(int i=1; i<=n; i++){
		int x; scanf("%d",&x);
		a[i] += m - x;
		a[i] %= m;
	}
	if(n % 2 == 1){
		lint dap = 0;
		for(int i=1; i<=n; i++){
			if(i % 2 == 1) dap += a[i];
			else dap += m - a[i];
		}
		dap %= m;
		dap = m - dap;
		dap %= m;
		if(dap % 2 != 0) dap += m;
		if(dap % 2 != 0){
			puts("-1");
			return 0;
		}
		//dap %= m;
		a[1] += dap / 2;
		a[n] += dap / 2;
		a[1] %= m;
		a[n] %= m;
		lint ret = solve() + min(dap / 2, m - dap / 2);
		if(m % 2 == 0){
			a[1] += m / 2;
			a[n] += m / 2;
			a[1] %= m;
			a[n] %= m;
			ret = min(ret, solve() + m / 2 - dap / 2);
		}
		printf("%lld\n", ret);
	}
	else{
		lint dap = 0;
		vector<lint> su_list;
		for(int i=1; i<=n; i++){
			if(i % 2 == 0) dap += a[i];
			else dap += m - a[i];
			if(i != n){
				su_list.push_back(dap % m);
				su_list.push_back(dap % m + m);
				su_list.push_back(dap % m + m + m);
			}
		}
		if(dap != 0){
			puts("-1");
			return 0;
		}
		sort(su_list.begin(), su_list.end());
		vector<lint> vect = su_list;
		for(int i=1; i<vect.size(); i++) vect[i] += vect[i-1];
		auto gs = [&](int x, int y){
			lint ret = 0;
			if(y >= 0) ret += vect[y];
			if(x > 0) ret -= vect[x - 1];
			return ret;
		};
		dap %= m;
		int ptr = 0;
		lint ans = 1e18;
		for(int i=(n-1); i<2*n-2; i++){
			while(su_list[i] - su_list[ptr] > m / 2) ptr++;
			lint sum = su_list[i] * (i - ptr + 1) - gs(ptr, i);
			sum += gs(i + 1, ptr + n - 2) - su_list[i] * (ptr + n - 2 - i);
			/*
			for(int j=ptr; j<=i; j++){
				sum += su_list[i] - su_list[j];
			}
			for(int j=i+1; j<ptr+n-1; j++){
				sum += su_list[j] - su_list[i];
			}*/
			ans = min(ans, sum);
		}
		cout << ans << endl;
	}
}
