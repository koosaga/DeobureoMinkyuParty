#include<bits/stdc++.h>

using namespace std;

mt19937 rng(58123);

bool good[10050];


int main() {
int N;
	//scanf("%d", &N);
	good[1] = 1;
	for(int i = 2; i < 10000; i++) {
		bool cur = true;
		for(int j = 2; j * j <= i && cur; j++) {
			if(i % j == 0) cur = false;
		}
		good[i] = cur;
	}
	
	for(int N = 1; N <= 100; N++) {
	vector<int> v(N);
	for(int i = 1; i <= N; i++) v[i-1] = i;
		clock_t st = clock();
		printf("%d: ", N);
		bool ans = true;
		while(clock() < st + CLOCKS_PER_SEC * 10) {
			if(N==2) break;
			shuffle(v.begin(), v.end(), rng);
			int sum = 0; ans = true;
			for(int x : v) {
				sum += x;
				if(good[sum]) {
					ans = false;
					break;
				}
			}	
			if(ans) {
				printf("[");
				for(int x : v) printf("%d, ", x);
				puts("],");
				break;
			}
		}
		
		if(!ans) {
			puts("[-1],");
		}
	}
	
	puts("-1");
	return 0;
}
