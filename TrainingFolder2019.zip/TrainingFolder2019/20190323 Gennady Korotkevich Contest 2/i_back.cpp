#include <bits/stdc++.h>

using namespace std;

using lint = long long;

const int N_ = int(1.1e5);

int tree[N_];

	static string dig[N_];
lint f(int n) {
	static int a[N_];
	
	for(int i = 1; i <= n; i++) {
		a[i] = i;
	}
	sort(a+1, a+n+1, [&](const int &i, const int &j) {
		return dig[i] < dig[j];
	});
	fill(tree+1, tree+n+1, 0);
	lint ans = 0;
	for(int i = 1; i <= n; i++) {
		int x = a[i];
		ans += i-1;
		while(x > 0) {
			ans -= tree[x];
			x &= x-1;
		}
		x = a[i];
		while(x <= n) {
			tree[x] += 1;
			x += x & -x;
		}
	}
	return ans;	
}
lint g(int len) {
	vector<string> vec;
	vec.emplace_back("");
	for(int l = 1, m = 10; l <= len; l++) {
		for(int i = 0; i < m; i++) {
			static char tmp[10];
			for(int j = l, x = i; j--; x /= 10) {
				tmp[j] = x % 10 + '0';
			}
			tmp[l] = 0; 
			vec.push_back(tmp);
		}
		m *= 10;
	}
	
	sort(vec.begin(), vec.end());
	
	lint ans=0;
	int cnt=0;
	memset(tree,0,sizeof tree);
	for(string str : vec) {
		//puts(("1"+str).c_str());
		int yy = atoi(("1"+str).c_str())+1;
		assert(yy<N_);
		
		int x = yy;
		
		if(str[0]=='1'){
		//ans += cnt++;
		while(x > 0) {
			ans -= tree[x];
			x &= x-1;
		}
		}
		
		if(str[0]=='0'){
		x = yy;
		while(x < N_) {
			tree[x] += 1;
			x += x & -x;
		}
		}
	}
	return ans;	
}

void factorize(lint w) {
	lint v = w;
	for(lint i = 2; v > 1 && i * i <= w; i++) {
		int c = 0;
		while(v % i == 0) {
			v /= i;
			c++;
		}
		if(c > 0) {
			printf("%lld^%d ", i, c);
		}
	}
	if(v > 1) {
			printf("%lld^%d ", v, 1);
	
	}
	puts("");
}


int main() {
	for(int i = 1; i < N_; i++) {
		dig[i] = dig[i / 10];
		dig[i] += char(i % 10 + '0');
	}
	int n;scanf("%d",&n);
	printf("%lld\n",f(n));
	return 0;

/**/
	
	/*
1 -1 0
 > 
10 -1 0
 > 
100 -1 1
 > 5^1 
1000 -1 121
 > 11^2 
10000 -1 12421
 > 12421^1 
100000 -1 1246421
 > 11^2 10301^1 
1000000 -1 124696421
 > 3079^1 40499^1 
10000000 -1 12470296421
 > 11^2 103060301^1 
 
1 -1 0
 > 
10 -1 0
 > 
100 -1 450
 > 2^1 3^2 5^2 
1000 -1 54450
 > 2^1 3^2 5^2 11^2 
10000 -1 5589450
 > 2^1 3^2 5^2 12421^1 
100000 -1 560889450
 > 2^1 3^2 5^2 11^2 10301^1 
1000000 -1 56113389450
 > 2^1 3^2 5^2 3079^1 40499^1 
 
>>> a=[0,10,1210,124210,12464210,1246964210,124702964210]
>>> b=[a[i]-a[i-1] for i in range(1,len(a))]
>>> b
[10, 1200, 123000, 12340000, 1234500000, 123456000000]


g = [0]
for l in range(1,10):
	d = 0
	for i in range(1,l+1):
		d += 10**(l-i) * i
	g.append(g[-1] + 45 * 10**l * d)
	
	
>>> def f(n):
...  s=0
...  for i in range(n): 
...   for j in range(i):
...    s += 10**(i+j) # (i+j) /\ (delta array)
...  return s
... 
>>> 
>>> f(1)
0
>>> f(2)
10
>>> f(3)
1110
>>> f(4)
112110
>>> f(5)
11222110
>>> f(6)
1122322110
>>> f(7)
112233322110

*/


	for(int i = 1, l = 0; i <= int(1e7); i *= 10, l++) {
		lint gg = g(l);
		//assert(gg % 45 == 0);
		//gg /= 45;
		printf("%d %lld %lld\n", i, f(i), gg);	
		printf(" > ");
		factorize(gg);
	}
	
	return 0;
}
