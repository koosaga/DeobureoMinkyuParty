#include <bits/stdc++.h>
using namespace std;
const int MAXN = 200005;
const int MAXT = 1050000;
using lint = long long;

struct work{
	int r, x, s, e, idx;
	bool operator<(const work &w)const{
		return r < w.r;
	}
}a[MAXN];

struct seg{
	struct node{
		lint pfx, sum;
	}tree[MAXT], lazy[MAXT];
	node merge(node a, node b){
		return (node){max(a.pfx, a.sum + b.pfx), a.sum + b.sum};
	}
	node up(node a, node b){
		return (node){max(a.pfx, b.pfx), max(a.sum, b.sum)};
	}
	void lazydown(int p){
		lazy[2*p] = merge(lazy[2*p], lazy[p]);
		lazy[2*p+1] = merge(lazy[2*p+1], lazy[p]);
		tree[2*p] = merge(tree[2*p], lazy[p]);
		tree[2*p+1] = merge(tree[2*p+1], lazy[p]);
		lazy[p] = {0, 0};
	}
	lint query(int s, int e, int ps, int pe, int p){
		if(e < ps || pe < s) return 0;
		if(s <= ps && pe <= e) return tree[p].pfx;
		lazydown(p);
		int pm = (ps + pe) / 2;
		return max(query(s, e, ps, pm, 2*p), query(s, e, pm+1, pe, 2*p+1));
	}
	void add(int s, int e, int ps, int pe, int p, node v){
		if(e < ps || pe < s) return;
		if(s <= ps && pe <= e){
			lazy[p] = merge(lazy[p], v);
			tree[p] = merge(tree[p], v);
			return;
		}
		lazydown(p);
		int pm = (ps + pe) / 2;
		add(s, e, ps, pm, 2*p, v);
		add(s, e, pm+1, pe, 2*p+1, v);
		tree[p] = up(tree[2*p], tree[2*p+1]);
	}
}seg;

int n;
lint dap[MAXN];

int main(){
	scanf("%d",&n);
	vector<int> v;
	for(int i=0; i<n; i++){
		scanf("%d %d %d %d",&a[i].r,&a[i].x,&a[i].s,&a[i].e);
		a[i].idx = i;
		v.push_back(a[i].s);
		v.push_back(a[i].e + 1);
	}
	sort(v.begin(), v.end());
	v.resize(unique(v.begin(), v.end()) - v.begin());
	for(int i=0; i<n; i++){
		a[i].s = lower_bound(v.begin(), v.end(), a[i].s) - v.begin();
		a[i].e = lower_bound(v.begin(), v.end(), a[i].e+1) - v.begin();
	}
	sort(a, a + n);
	for(int i=0; i<n; i++){
		dap[a[i].idx] = seg.query(a[i].s, a[i].e - 1, 0, 2 * n - 1, 1) + a[i].x;
		seg.add(a[i].s, a[i].e - 1, 0, 2 * n - 1, 1, {max(a[i].x, 0), a[i].x});
	}
	for(int i=0; i<n; i++) printf("%lld\n", dap[i]);
}
