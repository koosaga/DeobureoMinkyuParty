#include <bits/stdc++.h>
using namespace std;
const int MAXN = 55;
int n, m, q;
vector<int> gph[MAXN];
int par[MAXN], vis[MAXN];

vector<int> extend(vector<int> v){
	if(!vis[v.back()]){
		puts("-1");
		exit(0);
	}
	while(v.back() != n){
		v.push_back(par[v.back()]);
	}
	return v;
}

int main(){
	scanf("%d %d",&n,&m);
	for(int i=0; i<m; i++){
		int s, e; scanf("%d %d %*d",&s,&e);
		gph[s].push_back(e);
		gph[e].push_back(s);
	}
	queue<int> que;
	vector<vector<int>> paths;
	que.push(n);
	vis[n] = 1;
	while(!que.empty()){
		int x = que.front();
		que.pop();
		for(auto &i : gph[x]){
			if(!vis[i]){
				vis[i] = 1;
				par[i] = x;
				que.push(i);
			}
		}
	}
	scanf("%d",&q);
	for(int i=0; i<q; i++){
		int x; scanf("%d",&x);
		vector<int> v(x);
		for(auto &j : v) scanf("%d",&j);
		paths.push_back(extend(v));
	}
	if(q % 2 == 0){
		paths.push_back(extend({1}));
	}
	for(int i=0; i<q; i++){
		swap(paths[0], paths[i]);
		vector<int> ans;
		for(int j=0; j<paths.size(); j++){
			if(j % 2 == 0){
				for(auto &k : paths[j]) ans.push_back(k);
			}
			else{
				for(int k=(int)paths[j].size()-2; k>=1; k--){
					ans.push_back(paths[j][k]);
				}
			}
		}
		printf("%d ", ans.size());
		for(auto &i : ans) printf("%d ", i);
		puts("");
		swap(paths[0], paths[i]);
	}
}
