#include <bits/stdc++.h>

using namespace std;

using lint = long long;

const lint MOD = 1000000009;

struct myhash {
	lint v1, v2;

	myhash(lint v1_ = 0, lint v2_ = 0): v1(v1_), v2(v2_) { }

	myhash operator* (myhash h) {
		return myhash(v1 * h.v1 % MOD, v2 * h.v2 % MOD);
	}

	myhash operator- (myhash h) {
		return myhash((v1 - h.v1 + MOD) % MOD, (v2 - h.v2 + MOD) % MOD);
	}

	myhash operator+ (myhash h) {
		return myhash((v1 + h.v1) % MOD, (v2 + h.v2) % MOD);
	}

	bool operator== (myhash h) {
		return v1 == h.v1 && v2 == h.v2;
	}
};

const int N_ = int(3.1e5);

myhash pw[N_ * 2];
const myhash base(999999937, 993244853);

myhash deq[N_ * 2];
int ans[N_ * 2];

int A[N_];
bool good[N_];

void solve() {
	int N, M;
	scanf("%d%d", &N, &M);
	for(int i = 0; i < N; i++) {
		scanf("%d", &A[i]);
		good[i] = true;
	}
	for(int i = 0; i < M; i++) {
		int x; scanf("%d", &x);
		good[x-1] = false;
	}
	for(int i = 0; i <= 2*N+1; i++) {
		deq[i].v1 = deq[i].v2 = 0;
		ans[i] = 0;
	}

	// 5 4 0 2 2 1 2
	int f, r;
	f = r = N+1;
	int i = 0;
	for(int j = 0; j < N; j++) if(good[j]) {
		for(int x = i; x <= j; x++) {
			ans[r] = A[x];
			r += 1;
			deq[r] = deq[r - 1] + myhash(A[x], A[x]) * pw[r-1];

			f -= 1;
			ans[f] = A[x];
			deq[f] = deq[f+1] - myhash(A[x],A[x]) * pw[f];
		}

		int r_ = f + (j - i + 1);
		int low = 1, high = j+1, pos = 0;
		while(low <= high) {
			int mid = (low + high) >> 1;

			myhash h1 = (deq[f+mid] - deq[f]) * pw[r_ - f];
			myhash h2 = (deq[r_+mid] - deq[r_]);
			if(h1 == h2) {
				pos = mid;
				low = mid + 1;
			}else {
				high = mid - 1;
			}
		}

		if(ans[f + pos] < ans[r_ + pos]) {
			r -= (j-i+1);
		}else {
			f += (j-i+1);
		}

		/*for(int x = f; x < r; x++) {
			printf("%d ", ans[x]);
		}
		puts("\n");*/

		i = j+1;
	}
	while(i < N) {
		ans[r++] = A[i++];
	}

	assert(r - f == N);

	const lint HM = 20181125, HB = 37;
	lint hashed = 0, cur = 1;
	for(int x = f; x < r; x++) {
		(hashed += cur * ans[x] % HM) %= HM;
		(cur *= 37) %= HM;
	}
	printf("%lld\n", hashed);


}


int main() {
	pw[0] = myhash(1, 1);
	for(int i = 1; i < N_ * 2; i++) {
		pw[i] = pw[i-1] * base;
	}

	int T;
	scanf("%d", &T);
	for(int t=1;t<=T;t++) {
		printf("Case %d: ", t);
		solve();
	}

	return 0;
}