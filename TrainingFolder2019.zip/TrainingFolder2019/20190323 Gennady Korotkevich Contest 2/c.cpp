#include <bits/stdc++.h>
using namespace std;
const int mod = 1e9 + 123;
const int pwr = 8753;
using lint = long long;

int main(){
	lint ret = 1;
	for(int i=0; i<=1000000; i++){
		if(ret < i + 5 || ret > mod - i - 5) printf("%d %lld\n", i + 1, ret);
		ret = ret * pwr % mod;
	}
}
