#include <bits/stdc++.h>
using namespace std;

char arr[250010];
vector<int> lis[250010];
vector<int> pos[26];

void solve()
{
	int n, i, j;
	scanf("%s", arr);
	
	n = strlen(arr);
	
	for(i=0; i<26; i++)
		pos[i].clear();
	for(i=0; i<n; i++)
		pos[arr[i] - 'a'].push_back(i);
	
	for(i=0; i<26; i++)
	{
		int sz = (int)pos[i].size();
		if(sz == 0)
			continue;
		
		if(sz <= 2)
		{
			printf("0 ");
			continue;
		}
		
		int res = 0;
		for(j=1;; j++)
		{
			int len = (sz - 1) * j + 1;
			if(len > n)
				break;
			
			for(int x : pos[i])
				lis[x % j].push_back(x);
			
			for(int x : pos[i])
			{
				if(lis[x % j].empty())
					continue;
				
				if( x % j + 1LL * (sz - 1) * j < n )
				{
					queue<int> q;
					for(int c : lis[x % j])
					{
						q.push(c);
						while(c - q.front() >= len)
							q.pop();
						res = max(res, (int)q.size());
					}
				}
				
				lis[x % j].clear();
			}	
		}
		
		res = sz - res;
		printf("%d ", res);
	}
}

int main()
{
	int t, i;
	scanf("%d", &t);
	for(i=0; i<t; i++)
		solve();
	return 0;
}
