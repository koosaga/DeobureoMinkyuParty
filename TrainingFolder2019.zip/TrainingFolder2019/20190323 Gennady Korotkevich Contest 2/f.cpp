#include<bits/stdc++.h>

using namespace std;

char arr[1000010];

void solve()
{
	int n, i;
	scanf("%s", arr);
	n = strlen(arr);
	
	vector<int> v1, v2;
	for(i=0; i<n; i++)
	{
		if(arr[i] == 'C')
			break;
		v1.push_back(arr[i]);
	}
	for(i=n-1; i>=0; i--)
	{
		if(arr[i] == 'C')
			break;
		v2.push_back(arr[i]);
	}
	
	int t = 0;
	while(1)
	{
		if(!v1.empty() && v1.back() == 'A' + t && (v2.empty() || v2.back() != 'A' + t || v1.front() == 'A' + t))
			v1.pop_back();
		else if(!v2.empty() && v2.back() == 'A' + t)
			v2.pop_back();
			
		if(v1.empty() && v2.empty())
		{
			if(t == 0)
				puts("Bananenfrau");
			else
				puts("Apfelmann");
			return;
		}
		
		t = 1 - t;
	}
}

int main()
{
	int t, i;
	scanf("%d", &t);
	for(i=0; i<t; i++)
		solve();
	return 0;
}
