#include<bits/stdc++.h>

using namespace std;

const int N_ = int(2.1e2);

int N;

char S[N_];


using lint = long long;


lint pref_same[N_+2];
lint pref_same_diag[N_+2];

void same2 (int l, lint c) {
	if(l <= 0) return;
	//printf("%d %lld\n",l,c);
	
	pref_same[0] += c;
	pref_same[l+1] -= 2 * c;
	pref_same[2*l+1] += c;
	
	pref_same_diag[0] += c;
	pref_same_diag[2*l+1] -= c;
}

lint ans[N_+2];

lint cntg[N_+2];

lint prefg[N_+2];

lint offset[N_+2], slope[N_+2];

lint pref_leftover[N_+2];

lint comb2 (lint x) {
	return x * (x-1) / 2;
}

int main() {
	scanf("%s", S);
	N = strlen(S);
	reverse(S, S+N);
	
	for(int i = 0; i < N; i++) {
		for(int j = i+1; j < N; j++) {
			for(int k = 0; k < j; k++)
				ans[i+k] += (S[i] - '0' + (i==0)) * (9 - (S[j] - '0'));
		}
	}
	
	for(int i = N-1; i >= 0; i--) {
		int l = i;
		
		int no_0;
		if(i == N-1) {
			no_0 = 1;	
		}else {
			no_0 = 0;
		}
		
		int d = S[i] - '0';
		int d_minus_no_0 = d - no_0;
		
		same2(l, comb2(d_minus_no_0));
		same2(l - 1, comb2(9 - d));
		same2(l - 1, (d_minus_no_0) * (9 - d));
			
		pref_leftover[0] += d_minus_no_0 * (10 - d);
		pref_leftover[l] -= d_minus_no_0 * (10 - d);
		
		same2(l - 1, d_minus_no_0);
		same2(l - 1, 9 - d);
		
		if(l > 0) cntg[l-1] += d_minus_no_0;
		if(l > 1) cntg[l-2] += 9 - d;
	}

	{
		for(int rep = 0; rep < 2; rep++) {
			for(int i = 1; i < N_; i++) {
				pref_same[i] += pref_same[i-1];
			}
		}
		
		
		for(int i = 1; i < N_; i++) {
			pref_same_diag[i] += pref_same_diag[i-1];
			offset[i] += offset[i-1];
			pref_leftover[i] += pref_leftover[i-1];
		}
		
		for(int rep = 0; rep < 2; rep++) {
			for(int i = 1; i < N; i++) {
				slope[i] += slope[i-1];
			}
		}
		slope[N] = 0;
		
		for(int i = N_; --i >= 0; ) {
			cntg[i] += cntg[i+1];
		}
		
		for(int i = 0; i < 10; i++) {
			printf("%d %lld\n",i,cntg[i]);
		}
		
		for(int l = 0; l <= N; l++) {
			prefg[2*l-1] += cntg[l] * 45;
			prefg[l-1] -= cntg[l] * 45;
		}
		
		for(int rep = 0; rep < 2; rep++) {
			for(int i = N_; --i >= 0; ) {
				prefg[i] += prefg[i+1];
			}
		}
		
		for(int i = 0; i < N_; i++) {
			ans[i] += (pref_same[i] - pref_same_diag[i]) / 2;
			ans[i] += prefg[i];
			ans[i] += offset[i] + slope[i];
			ans[i] += pref_leftover[i];
			
			ans[i+1] += ans[i] / 10;
			ans[i] %= 10;
		}
	}
	
	bool printing = false;
	for(int i = N_; i >= 0; i--) {
		if(ans[i] > 0) printing = true;
		if(printing) putchar(ans[i]+'0');
	}
	if(!printing) {
		putchar('0');
	}
	
	puts("");
	return 0;
}
