#include<bits/stdc++.h>

using namespace std;

int main()
{
	int t;
	scanf("%d", &t);
	
	if(t == 0 || t == 2)
	{
		puts("2 5");
		puts("a b c");
		puts("b x y");
		puts("c z w");
		puts("d e f");
		puts("x y d");
	}
	else
	{
		puts("2 6");
		puts("a b c");
		puts("b x y");
		puts("c z w");
		puts("d e f");
		puts("f g h");
		puts("a d e");
	}
	
	return 0;
}
