import random

print("15 69")
for i in range(0, 15):
	print(random.randint(0, 420),random.randint(0, 420),random.randint(500, 920),random.randint(500, 920))



