print(201*201)
for a in range(201):
	for b in range(201):
		print(a, b)