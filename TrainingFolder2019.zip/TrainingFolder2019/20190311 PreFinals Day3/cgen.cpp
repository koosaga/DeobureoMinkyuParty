#include <bits/stdc++.h>

int main(){
	for(int i=0; i<100; i++) putchar('a');
	printf("\n100\n");
	for(int i=0; i<100; i++){
		for(int j=0; j<100; j++) putchar('a');
		puts("");
	}
}
